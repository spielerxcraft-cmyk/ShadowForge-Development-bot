import { Client, GatewayIntentBits, Partials } from "discord.js";
import { registerEvent } from "./handlers/eventHandler.js";
import { slashCommands, prefixCommands } from "./handlers/commandHandler.js";
import { botLogger } from "./utils/logger.js";

// Events
import readyEvent from "./events/ready.js";
import interactionCreateEvent from "./events/interactionCreate.js";
import messageCreateEvent from "./events/messageCreate.js";
import guildMemberAddEvent from "./events/guildMemberAdd.js";
import guildMemberRemoveEvent from "./events/guildMemberRemove.js";
import messageDeleteEvent from "./events/messageDelete.js";
import messageUpdateEvent from "./events/messageUpdate.js";
import guildMemberUpdateEvent from "./events/guildMemberUpdate.js";

// Slash Commands
import warnCmd from "./commands/moderation/warn.js";
import banCmd from "./commands/moderation/ban.js";
import kickCmd from "./commands/moderation/kick.js";
import timeoutCmd from "./commands/moderation/timeout.js";
import unbanCmd from "./commands/moderation/unban.js";
import purgeCmd from "./commands/moderation/purge.js";
import slowmodeCmd from "./commands/moderation/slowmode.js";
import lockCmd from "./commands/moderation/lock.js";
import warningsCmd from "./commands/moderation/warnings.js";
import ticketCmd from "./commands/tickets/ticket.js";
import giveawayCmd from "./commands/giveaway/giveaway.js";
import rankCmd from "./commands/rewards/rank.js";
import leaderboardCmd from "./commands/rewards/leaderboard.js";
import dailyCmd from "./commands/rewards/daily.js";
import balanceCmd from "./commands/rewards/balance.js";
import userinfoCmd from "./commands/utility/userinfo.js";
import serverinfoCmd from "./commands/utility/serverinfo.js";
import avatarCmd from "./commands/utility/avatar.js";
import pollCmd from "./commands/utility/poll.js";
import roleinfoCmd from "./commands/utility/roleinfo.js";
import helpCmd from "./commands/utility/help.js";
import verifyCmd from "./commands/security/verify.js";
import securityCmd from "./commands/security/antiraid.js";
import welcomeCmd from "./commands/welcome/welcome.js";
import announceCmd from "./commands/announcements/announce.js";
import invitesCmd from "./commands/invites/invites.js";
import ownerCmd from "./commands/owner/owner.js";
import aiCmd from "./commands/ai/ai.js";
import websiteCmd from "./commands/utility/website.js";

// Prefix Commands
import prefixHelp from "./commands/prefix/help.js";
import prefixPing from "./commands/prefix/ping.js";
import prefixRank from "./commands/prefix/rank.js";
import prefixBalance from "./commands/prefix/balance.js";
import prefixDaily from "./commands/prefix/daily.js";
import prefixUserinfo from "./commands/prefix/userinfo.js";
import prefixServerinfo from "./commands/prefix/serverinfo.js";
import prefixAvatar from "./commands/prefix/avatar.js";
import prefixPoll from "./commands/prefix/poll.js";
import prefixWarn from "./commands/prefix/warn.js";
import prefixBan from "./commands/prefix/ban.js";
import prefixKick from "./commands/prefix/kick.js";
import prefixPurge from "./commands/prefix/purge.js";
import prefixWarnings from "./commands/prefix/warnings.js";

export function createBot(): Client {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildInvites,
      GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember, Partials.User],
  });

  // Register slash commands
  const allSlashCommands = [
    warnCmd, banCmd, kickCmd, timeoutCmd, unbanCmd, purgeCmd, slowmodeCmd, lockCmd, warningsCmd,
    ticketCmd, giveawayCmd, rankCmd, leaderboardCmd, dailyCmd, balanceCmd,
    userinfoCmd, serverinfoCmd, avatarCmd, pollCmd, roleinfoCmd, helpCmd, websiteCmd,
    verifyCmd, securityCmd, welcomeCmd, announceCmd, invitesCmd, ownerCmd, aiCmd,
  ];
  for (const cmd of allSlashCommands) {
    slashCommands.set(cmd.data.name, cmd);
  }

  // Register prefix commands
  const allPrefixCommands = [
    prefixHelp, prefixPing, prefixRank, prefixBalance, prefixDaily,
    prefixUserinfo, prefixServerinfo, prefixAvatar, prefixPoll,
    prefixWarn, prefixBan, prefixKick, prefixPurge, prefixWarnings,
  ];
  for (const cmd of allPrefixCommands) {
    prefixCommands.set(cmd.name, cmd);
    if (cmd.aliases) {
      for (const alias of cmd.aliases) {
        prefixCommands.set(alias, cmd);
      }
    }
  }

  // Register events
  const events = [
    readyEvent, interactionCreateEvent, messageCreateEvent,
    guildMemberAddEvent, guildMemberRemoveEvent,
    messageDeleteEvent, messageUpdateEvent, guildMemberUpdateEvent,
  ];
  for (const event of events) {
    registerEvent(client, event);
  }

  return client;
}

export async function startBot(): Promise<void> {
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    botLogger.warn("DISCORD_TOKEN not set — bot will not start");
    return;
  }

  const client = createBot();

  try {
    await client.login(token);
    botLogger.info("ShadowForge Bot connected to Discord Gateway");
  } catch (err) {
    botLogger.error(err, "Failed to login to Discord");
  }
}
