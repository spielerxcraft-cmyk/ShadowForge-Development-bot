import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const faqs: Record<string, string> = {
  "how to create ticket": "Click on the ticket panel in the support channel or use `/ticket create`!",
  "how to get roles": "You can earn roles through leveling up or by using reaction roles!",
  "how to report": "Use `/ticket create report` or the ticket panel to report a user.",
  "what is shadowforge": "ShadowForge Development is a professional Discord development team providing bots, servers, and automation solutions.",
  "bot commands": "Use `/help` to see all available commands, or try `/` to see the slash command list!",
  "how to apply": "Use `/ticket create application` to submit a staff application!",
  "partnership": "Interested in partnering? Use `/ticket create partnership` to open a partnership ticket!",
};

function findFAQ(query: string): string | null {
  const lower = query.toLowerCase();
  for (const [key, answer] of Object.entries(faqs)) {
    if (lower.includes(key)) return answer;
  }
  return null;
}

function generateAIResponse(prompt: string): string {
  const faq = findFAQ(prompt);
  if (faq) return faq;

  const responses = [
    "That's a great question! I'd recommend checking our documentation or opening a support ticket for personalized help.",
    "I'm not entirely sure about that, but our support team can help! Use `/ticket create support` to get assistance.",
    "Interesting! Could you provide more details? You can also visit our support channel for help.",
    "I understand your question. Our team is available to assist — feel free to open a ticket!",
  ];
  return responses[Math.floor(Math.random() * responses.length)]!;
}

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("ai")
    .setDescription("AI-powered assistance")
    .addSubcommand((s) =>
      s.setName("chat").setDescription("Chat with the AI assistant")
        .addStringOption((o) => o.setName("message").setDescription("Your message").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("translate").setDescription("Translate text")
        .addStringOption((o) => o.setName("text").setDescription("Text to translate").setRequired(true))
        .addStringOption((o) => o.setName("to").setDescription("Target language").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("faq").setDescription("Get answers to common questions")
        .addStringOption((o) => o.setName("question").setDescription("Your question").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("summarize").setDescription("Summarize a piece of text")
        .addStringOption((o) => o.setName("text").setDescription("Text to summarize").setRequired(true))
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "chat") {
      const message = interaction.options.getString("message", true);
      const response = generateAIResponse(message);
      const embed = new EmbedBuilder()
        .setColor(Colors.purple as ColorResolvable)
        .setTitle("🤖 AI Assistant")
        .addFields(
          { name: "You", value: message },
          { name: "Assistant", value: response },
        )
        .setFooter({ text: "ShadowForge AI • Powered by smart automation" })
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "faq") {
      const question = interaction.options.getString("question", true);
      const answer = findFAQ(question) ?? "I don't have a specific FAQ for that. Try opening a support ticket!";
      const embed = new EmbedBuilder()
        .setColor(Colors.info as ColorResolvable)
        .setTitle("❓ FAQ")
        .addFields(
          { name: "Question", value: question },
          { name: "Answer", value: answer },
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "translate") {
      const text = interaction.options.getString("text", true);
      const to = interaction.options.getString("to", true);
      const embed = new EmbedBuilder()
        .setColor(Colors.info as ColorResolvable)
        .setTitle("🌐 Translation")
        .addFields(
          { name: "Original", value: text },
          { name: `Translated to ${to}`, value: `*(Translation feature — connect an API for live translations)*` },
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "summarize") {
      const text = interaction.options.getString("text", true);
      const words = text.split(" ");
      const summary = words.length > 30 ? words.slice(0, 30).join(" ") + "..." : text;
      const embed = new EmbedBuilder()
        .setColor(Colors.info as ColorResolvable)
        .setTitle("📝 Summary")
        .addFields(
          { name: "Original Length", value: `${words.length} words`, inline: true },
          { name: "Summary", value: summary },
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      return;
    }
  },
};

export default command;
