import {
  SlashCommandBuilder, type ChatInputCommandInteraction,
  PermissionFlagsBits, EmbedBuilder, type ColorResolvable,
} from "discord.js";
import { Colors } from "../../utils/colors.js";
import { successEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("announce")
    .setDescription("Send an announcement")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s.setName("send").setDescription("Send an announcement embed")
        .addStringOption((o) => o.setName("title").setDescription("Announcement title").setRequired(true))
        .addStringOption((o) => o.setName("message").setDescription("Announcement message").setRequired(true))
        .addChannelOption((o) => o.setName("channel").setDescription("Target channel").setRequired(false))
        .addRoleOption((o) => o.setName("ping").setDescription("Role to ping").setRequired(false))
        .addStringOption((o) =>
          o.setName("color").setDescription("Embed color").setRequired(false)
            .addChoices(
              { name: "Blue (Default)", value: "blue" },
              { name: "Green (Success)", value: "green" },
              { name: "Red (Warning)", value: "red" },
              { name: "Gold", value: "gold" },
            )
        )
    )
    .addSubcommand((s) =>
      s.setName("plain").setDescription("Send a plain text announcement")
        .addStringOption((o) => o.setName("message").setDescription("Message").setRequired(true))
        .addChannelOption((o) => o.setName("channel").setDescription("Target channel").setRequired(false))
        .addRoleOption((o) => o.setName("ping").setDescription("Role to ping").setRequired(false))
    )
    .addSubcommand((s) =>
      s.setName("schedule").setDescription("Schedule an announcement")
        .addStringOption((o) => o.setName("message").setDescription("Announcement message").setRequired(true))
        .addIntegerOption((o) => o.setName("minutes").setDescription("Minutes until send").setRequired(true).setMinValue(1))
        .addChannelOption((o) => o.setName("channel").setDescription("Target channel").setRequired(false))
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();

    const colorMap: Record<string, number> = { blue: Colors.shadowforge, green: Colors.success, red: Colors.error, gold: Colors.gold };

    if (sub === "send") {
      const title = interaction.options.getString("title", true);
      const message = interaction.options.getString("message", true);
      const channel = (interaction.options.getChannel("channel") ?? interaction.channel)!;
      const ping = interaction.options.getRole("ping");
      const colorKey = interaction.options.getString("color") ?? "blue";

      const embed = new EmbedBuilder()
        .setColor((colorMap[colorKey] ?? Colors.shadowforge) as ColorResolvable)
        .setTitle(`📢 ${title}`)
        .setDescription(message)
        .setFooter({ text: `ShadowForge Development • Announced by ${interaction.user.tag}` })
        .setTimestamp();

      const targetChannel = await interaction.guild.channels.fetch(channel.id).catch(() => null);
      if (targetChannel?.isTextBased()) {
        await (targetChannel as import("discord.js").TextChannel).send({ content: ping ? `${ping}` : undefined, embeds: [embed] });
      }
      await interaction.reply({ embeds: [successEmbed("Announced", `Announcement sent to ${channel}.`)], ephemeral: true });
      return;
    }

    if (sub === "plain") {
      const message = interaction.options.getString("message", true);
      const channel = (interaction.options.getChannel("channel") ?? interaction.channel)!;
      const ping = interaction.options.getRole("ping");
      const targetChannel = await interaction.guild.channels.fetch(channel.id).catch(() => null);
      if (targetChannel?.isTextBased()) {
        await (targetChannel as import("discord.js").TextChannel).send({ content: (ping ? `${ping} ` : "") + message });
      }
      await interaction.reply({ embeds: [successEmbed("Sent", "Plain message sent.")], ephemeral: true });
      return;
    }

    if (sub === "schedule") {
      const message = interaction.options.getString("message", true);
      const minutes = interaction.options.getInteger("minutes", true);
      const channel = (interaction.options.getChannel("channel") ?? interaction.channel)!;
      setTimeout(async () => {
        const targetChannel = await interaction.guild!.channels.fetch(channel.id).catch(() => null);
        if (targetChannel?.isTextBased()) {
          await (targetChannel as import("discord.js").TextChannel).send({ content: `📢 ${message}` });
        }
      }, minutes * 60 * 1000);
      await interaction.reply({ embeds: [successEmbed("Scheduled", `Announcement scheduled for **${minutes} minutes** from now.`)] });
      return;
    }
  },
};

export default command;
