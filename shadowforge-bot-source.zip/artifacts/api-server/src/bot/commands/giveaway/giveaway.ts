import {
  SlashCommandBuilder, type ChatInputCommandInteraction,
  PermissionFlagsBits,
} from "discord.js";
import { giveaways } from "../../systems/database.js";
import { buildGiveawayEmbed, buildGiveawayRow, scheduleGiveaway, endGiveaway } from "../../systems/giveaway.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("Giveaway management")
    .addSubcommand((s) =>
      s.setName("start").setDescription("Start a giveaway")
        .addStringOption((o) => o.setName("prize").setDescription("What to give away").setRequired(true))
        .addIntegerOption((o) => o.setName("duration").setDescription("Duration in minutes").setRequired(true).setMinValue(1))
        .addIntegerOption((o) => o.setName("winners").setDescription("Number of winners").setRequired(true).setMinValue(1).setMaxValue(20))
        .addStringOption((o) => o.setName("requirements").setDescription("Entry requirements").setRequired(false))
    )
    .addSubcommand((s) =>
      s.setName("end").setDescription("End a giveaway early")
        .addStringOption((o) => o.setName("message_id").setDescription("Giveaway message ID").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("reroll").setDescription("Reroll a giveaway")
        .addStringOption((o) => o.setName("message_id").setDescription("Giveaway message ID").setRequired(true))
    )
    .addSubcommand((s) => s.setName("list").setDescription("List active giveaways"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();

    if (sub === "start") {
      const prize = interaction.options.getString("prize", true);
      const duration = interaction.options.getInteger("duration", true);
      const winners = interaction.options.getInteger("winners", true);
      const requirements = interaction.options.getString("requirements") ?? undefined;
      const endsAt = Date.now() + duration * 60 * 1000;

      const data = { prize, winners, endsAt, hostId: interaction.user.id, entries: [], requirements };
      const embed = buildGiveawayEmbed(data);
      const row = buildGiveawayRow();
      const msg = await interaction.channel!.send({ embeds: [embed], components: [row] });

      giveaways.set(msg.id, { messageId: msg.id, channelId: msg.channelId, guildId: interaction.guild.id, ended: false, ...data });
      scheduleGiveaway(interaction.client, msg.id, duration * 60 * 1000);
      await interaction.reply({ embeds: [successEmbed("Giveaway Started", `Giveaway for **${prize}** started!`)], ephemeral: true });
      return;
    }

    if (sub === "end") {
      const msgId = interaction.options.getString("message_id", true);
      await endGiveaway(interaction.client, msgId);
      await interaction.reply({ embeds: [successEmbed("Giveaway Ended", "The giveaway has been ended and winners selected.")] });
      return;
    }

    if (sub === "reroll") {
      const msgId = interaction.options.getString("message_id", true);
      const g = giveaways.get(msgId);
      if (!g || g.entries.length === 0) { await interaction.reply({ embeds: [errorEmbed("No Entries", "No entries found for this giveaway.")], ephemeral: true }); return; }
      const winner = g.entries[Math.floor(Math.random() * g.entries.length)];
      await interaction.reply({ embeds: [successEmbed("Rerolled!", `New winner: <@${winner}> 🎉`)] });
      return;
    }

    if (sub === "list") {
      const active = [...giveaways.values()].filter((g) => !g.ended && g.guildId === interaction.guild!.id);
      if (active.length === 0) { await interaction.reply({ embeds: [errorEmbed("No Giveaways", "There are no active giveaways.")], ephemeral: true }); return; }
      const { shadowforgeEmbed } = await import("../../utils/embeds.js");
      const embed = shadowforgeEmbed("🎉 Active Giveaways", active.map((g) => `**${g.prize}** — Ends <t:${Math.floor(g.endsAt / 1000)}:R> • ${g.entries.length} entries`).join("\n"));
      await interaction.reply({ embeds: [embed] });
      return;
    }
  },
};
export default command;
