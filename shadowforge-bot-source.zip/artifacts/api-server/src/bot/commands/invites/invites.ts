import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { inviteTracker } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import { errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("invites")
    .setDescription("Invite tracking")
    .addSubcommand((s) =>
      s.setName("check").setDescription("Check invite stats for a user")
        .addUserOption((o) => o.setName("user").setDescription("User to check").setRequired(false))
    )
    .addSubcommand((s) => s.setName("leaderboard").setDescription("View invite leaderboard"))
    .addSubcommand((s) =>
      s.setName("add").setDescription("Add bonus invites")
        .addUserOption((o) => o.setName("user").setDescription("User").setRequired(true))
        .addIntegerOption((o) => o.setName("amount").setDescription("Amount to add").setRequired(true))
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();

    if (sub === "check") {
      const target = interaction.options.getUser("user") ?? interaction.user;
      const data = inviteTracker.get(`${interaction.guild.id}-${target.id}`);
      const embed = new EmbedBuilder()
        .setColor(Colors.shadowforge as ColorResolvable)
        .setTitle(`📨 Invites — ${target.username}`)
        .setThumbnail(target.displayAvatarURL())
        .addFields(
          { name: "Total Invites", value: `**${data?.uses ?? 0}**`, inline: true },
          { name: "Fake/Left", value: `**${(data?.fake ?? 0) + (data?.left ?? 0)}**`, inline: true },
          { name: "Valid", value: `**${Math.max(0, (data?.uses ?? 0) - (data?.fake ?? 0) - (data?.left ?? 0))}**`, inline: true },
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "leaderboard") {
      const guildPrefix = `${interaction.guild.id}-`;
      const entries = [...inviteTracker.entries()]
        .filter(([k]) => k.startsWith(guildPrefix))
        .map(([k, v]) => ({ userId: k.replace(guildPrefix, ""), ...v }))
        .sort((a, b) => b.uses - a.uses)
        .slice(0, 10);

      const medals = ["🥇", "🥈", "🥉"];
      const description = entries.length === 0
        ? "No invite data yet."
        : entries.map((e, i) => `${medals[i] ?? `**${i + 1}.**`} <@${e.userId}> — **${e.uses}** invites`).join("\n");

      const embed = new EmbedBuilder()
        .setColor(Colors.gold as ColorResolvable)
        .setTitle("📨 Invite Leaderboard")
        .setDescription(description)
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "add") {
      const user = interaction.options.getUser("user", true);
      const amount = interaction.options.getInteger("amount", true);
      const key = `${interaction.guild.id}-${user.id}`;
      const data = inviteTracker.get(key) ?? { inviterId: user.id, uses: 0, fake: 0, left: 0 };
      data.uses += amount;
      inviteTracker.set(key, data);
      const { successEmbed: s } = await import("../../utils/embeds.js");
      await interaction.reply({ embeds: [s("Bonus Invites Added", `Added **${amount}** bonus invites to ${user}.`)] });
      return;
    }
  },
};

export default command;
