import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban a member from the server")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((o) => o.setName("user").setDescription("User to ban").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for ban").setRequired(false))
    .addIntegerOption((o) => o.setName("days").setDescription("Delete message history (days)").setMinValue(0).setMaxValue(7).setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    const days = interaction.options.getInteger("days") ?? 0;
    if (!interaction.guild) return;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (member && !member.bannable) {
      await interaction.reply({ embeds: [errorEmbed("Cannot Ban", "I cannot ban this member.")], ephemeral: true });
      return;
    }
    await interaction.guild.members.ban(target.id, { reason, deleteMessageSeconds: days * 86400 });
    await interaction.reply({ embeds: [successEmbed("Member Banned", `${target.tag} has been banned.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
