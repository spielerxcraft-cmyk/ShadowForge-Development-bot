import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member from the server")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((o) => o.setName("user").setDescription("User to kick").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for kick").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    if (!interaction.guild) return;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) { await interaction.reply({ embeds: [errorEmbed("Not Found", "Member not found.")], ephemeral: true }); return; }
    if (!member.kickable) { await interaction.reply({ embeds: [errorEmbed("Cannot Kick", "I cannot kick this member.")], ephemeral: true }); return; }
    await member.kick(reason);
    await interaction.reply({ embeds: [successEmbed("Member Kicked", `${target.tag} has been kicked.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
