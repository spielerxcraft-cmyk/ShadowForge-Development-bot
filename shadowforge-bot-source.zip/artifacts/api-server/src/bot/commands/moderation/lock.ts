import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits, type TextChannel, PermissionsBitField } from "discord.js";
import { successEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Lock or unlock a channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addStringOption((o) => o.setName("action").setDescription("lock or unlock").setRequired(true).addChoices({ name: "lock", value: "lock" }, { name: "unlock", value: "unlock" }))
    .addStringOption((o) => o.setName("reason").setDescription("Reason").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const action = interaction.options.getString("action", true);
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    if (!interaction.guild) return;
    const channel = interaction.channel as TextChannel;
    const locked = action === "lock";
    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: locked ? false : null }, { reason });
    await interaction.reply({ embeds: [successEmbed(locked ? "Channel Locked" : "Channel Unlocked", `${channel} has been ${locked ? "🔒 locked" : "🔓 unlocked"}.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
