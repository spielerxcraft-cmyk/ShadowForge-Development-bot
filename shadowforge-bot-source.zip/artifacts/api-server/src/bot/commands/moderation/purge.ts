import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits, type TextChannel } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("purge")
    .setDescription("Delete multiple messages")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((o) => o.setName("amount").setDescription("Number of messages to delete (1-100)").setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption((o) => o.setName("user").setDescription("Filter by user").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const amount = interaction.options.getInteger("amount", true);
    const filterUser = interaction.options.getUser("user");
    if (!interaction.guild) return;
    const channel = interaction.channel as TextChannel;
    const messages = await channel.messages.fetch({ limit: amount });
    const toDelete = filterUser ? messages.filter((m) => m.author.id === filterUser.id) : messages;
    const deleted = await channel.bulkDelete(toDelete, true);
    const reply = await interaction.reply({ embeds: [successEmbed("Messages Purged", `Deleted **${deleted.size}** messages${filterUser ? ` from ${filterUser.tag}` : ""}.`)], fetchReply: true });
    setTimeout(() => reply.delete().catch(() => null), 5000);
  },
};
export default command;
