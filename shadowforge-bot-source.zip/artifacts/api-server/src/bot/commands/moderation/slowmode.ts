import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits, type TextChannel } from "discord.js";
import { successEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("slowmode")
    .setDescription("Set channel slowmode")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addIntegerOption((o) => o.setName("seconds").setDescription("Slowmode in seconds (0 to disable)").setRequired(true).setMinValue(0).setMaxValue(21600)),
  async execute(interaction: ChatInputCommandInteraction) {
    const seconds = interaction.options.getInteger("seconds", true);
    const channel = interaction.channel as TextChannel;
    await channel.setRateLimitPerUser(seconds);
    await interaction.reply({ embeds: [successEmbed("Slowmode Updated", seconds === 0 ? "Slowmode has been disabled." : `Slowmode set to **${seconds} seconds**.`)] });
  },
};
export default command;
