import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Timeout a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName("user").setDescription("User to timeout").setRequired(true))
    .addIntegerOption((o) => o.setName("minutes").setDescription("Duration in minutes").setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption((o) => o.setName("reason").setDescription("Reason").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user", true);
    const minutes = interaction.options.getInteger("minutes", true);
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    if (!interaction.guild) return;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) { await interaction.reply({ embeds: [errorEmbed("Not Found", "Member not found.")], ephemeral: true }); return; }
    await member.timeout(minutes * 60 * 1000, reason);
    await interaction.reply({ embeds: [successEmbed("Member Timed Out", `${target.tag} has been timed out for **${minutes} minutes**.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
