import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Unban a user from the server")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((o) => o.setName("user_id").setDescription("User ID to unban").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const userId = interaction.options.getString("user_id", true);
    const reason = interaction.options.getString("reason") ?? "No reason provided";
    if (!interaction.guild) return;
    await interaction.guild.members.unban(userId, reason).catch(() => null);
    await interaction.reply({ embeds: [successEmbed("User Unbanned", `User \`${userId}\` has been unbanned.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
