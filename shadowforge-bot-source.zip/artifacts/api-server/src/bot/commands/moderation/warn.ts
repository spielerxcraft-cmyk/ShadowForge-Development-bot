import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { addWarning, getUserWarnings } from "../../systems/database.js";
import { successEmbed, errorEmbed, warningEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption((o) => o.setName("user").setDescription("User to warn").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for warning").setRequired(true)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason", true);
    if (!interaction.guild) return;
    const count = addWarning(interaction.guild.id, target.id, reason, interaction.user.id);
    await interaction.reply({
      embeds: [
        successEmbed("Member Warned", `${target} has been warned.\n\n**Reason:** ${reason}\n**Total Warnings:** ${count}`),
      ],
    });
  },
};

export default command;
