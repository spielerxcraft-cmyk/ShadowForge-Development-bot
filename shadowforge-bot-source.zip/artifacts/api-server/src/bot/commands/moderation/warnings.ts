import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable, PermissionFlagsBits } from "discord.js";
import { getUserWarnings } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import { errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("View warnings for a user")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption((o) => o.setName("user").setDescription("User to check").setRequired(true)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user", true);
    if (!interaction.guild) return;
    const warns = getUserWarnings(interaction.guild.id, target.id);
    if (warns.length === 0) {
      await interaction.reply({ embeds: [errorEmbed("No Warnings", `${target.tag} has no warnings.`)], ephemeral: true }); return;
    }
    const embed = new EmbedBuilder()
      .setColor(Colors.warning as ColorResolvable)
      .setTitle(`⚠️ Warnings for ${target.tag}`)
      .setThumbnail(target.displayAvatarURL())
      .setDescription(warns.map((w, i) => `**#${i + 1}** — ${w.reason}\nBy <@${w.moderator}> • <t:${Math.floor(w.timestamp / 1000)}:R>`).join("\n\n"))
      .setFooter({ text: `Total: ${warns.length} warning(s)` })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
