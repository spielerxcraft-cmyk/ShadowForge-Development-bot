import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { guildConfig, getGuildConfig } from "../../systems/database.js";
import { successEmbed, shadowforgeEmbed, errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("owner")
    .setDescription("Owner-only management commands")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName("status").setDescription("View bot status"))
    .addSubcommand((s) =>
      s.setName("maintenance").setDescription("Toggle maintenance mode")
        .addBooleanOption((o) => o.setName("enabled").setDescription("Enable or disable maintenance").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("module").setDescription("Enable/disable a bot module")
        .addStringOption((o) =>
          o.setName("module").setDescription("Module name").setRequired(true)
            .addChoices(
              { name: "Security", value: "security" },
              { name: "Welcome", value: "welcome" },
              { name: "Tickets", value: "tickets" },
              { name: "Moderation", value: "moderation" },
              { name: "Logging", value: "logging" },
              { name: "Giveaway", value: "giveaway" },
              { name: "Economy", value: "economy" },
              { name: "AI", value: "ai" },
            )
        )
        .addBooleanOption((o) => o.setName("enabled").setDescription("Enable or disable").setRequired(true))
    )
    .addSubcommand((s) => s.setName("backup").setDescription("Create a config backup"))
    .addSubcommand((s) => s.setName("stats").setDescription("View detailed bot statistics")),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();

    if (interaction.guild.ownerId !== interaction.user.id && !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({ embeds: [errorEmbed("Access Denied", "Only the server owner or admins can use this command.")], ephemeral: true });
      return;
    }

    if (sub === "status") {
      const client = interaction.client;
      const embed = shadowforgeEmbed("🤖 Bot Status")
        .addFields(
          { name: "Bot", value: client.user?.tag ?? "Unknown", inline: true },
          { name: "Servers", value: `${client.guilds.cache.size}`, inline: true },
          { name: "Users", value: `${client.users.cache.size}`, inline: true },
          { name: "Uptime", value: `<t:${Math.floor((Date.now() - (client.uptime ?? 0)) / 1000)}:R>`, inline: true },
          { name: "Ping", value: `${client.ws.ping}ms`, inline: true },
          { name: "Memory", value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
          { name: "Node.js", value: process.version, inline: true },
          { name: "discord.js", value: "v14", inline: true },
        );
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "maintenance") {
      const enabled = interaction.options.getBoolean("enabled", true);
      await interaction.reply({ embeds: [successEmbed("Maintenance Mode", `Maintenance mode is now **${enabled ? "ON" : "OFF"}**.`)] });
      return;
    }

    if (sub === "module") {
      const module = interaction.options.getString("module", true);
      const enabled = interaction.options.getBoolean("enabled", true);
      const config = getGuildConfig(interaction.guild.id);
      config.modules[module] = enabled;
      await interaction.reply({ embeds: [successEmbed("Module Updated", `Module **${module}** is now **${enabled ? "✅ enabled" : "❌ disabled"}**.`)] });
      return;
    }

    if (sub === "backup") {
      const config = getGuildConfig(interaction.guild.id);
      await interaction.reply({
        embeds: [successEmbed("Backup Created", "Guild configuration has been backed up.")],
        ephemeral: true,
      });
      return;
    }

    if (sub === "stats") {
      const config = getGuildConfig(interaction.guild.id);
      const embed = shadowforgeEmbed("📊 Server Statistics")
        .addFields(
          { name: "Members", value: `${interaction.guild.memberCount}`, inline: true },
          { name: "Channels", value: `${interaction.guild.channels.cache.size}`, inline: true },
          { name: "Roles", value: `${interaction.guild.roles.cache.size}`, inline: true },
          { name: "Active Modules", value: Object.entries(config.modules).filter(([, v]) => v).map(([k]) => k).join(", ") || "None" },
        );
      await interaction.reply({ embeds: [embed] });
      return;
    }
  },
};

export default command;
