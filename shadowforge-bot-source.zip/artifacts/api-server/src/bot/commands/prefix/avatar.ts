import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "avatar",
  aliases: ["av", "pfp"],
  description: "Get a user's avatar",
  async execute(message: Message) {
    const target = message.mentions.users.first() ?? message.author;
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`🖼️ ${target.username}'s Avatar`)
      .setImage(target.displayAvatarURL({ size: 4096 }))
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
