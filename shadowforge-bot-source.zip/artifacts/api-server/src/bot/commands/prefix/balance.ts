import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserEconomy } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "balance",
  aliases: ["bal", "coins", "money"],
  description: "Check your balance",
  async execute(message: Message, args: string[], client: Client) {
    const target = message.mentions.users.first() ?? message.author;
    const eco = getUserEconomy(target.id);
    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle(`💰 Balance — ${target.username}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: "Coins", value: `**${eco.balance}** 🪙`, inline: true },
        { name: "Reputation", value: `**${eco.reputation}** ⭐`, inline: true },
      )
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
