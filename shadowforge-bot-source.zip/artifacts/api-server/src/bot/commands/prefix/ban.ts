import type { Message, Client } from "discord.js";
import { PermissionFlagsBits } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "ban",
  description: "Ban a member",
  usage: ".ban @user [reason]",
  async execute(message: Message, args: string[]) {
    if (!message.guild || !message.member) return;
    if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
      await message.reply({ embeds: [errorEmbed("No Permission", "You need Ban Members permission.")] }); return;
    }
    const target = message.mentions.users.first();
    if (!target) { await message.reply({ embeds: [errorEmbed("No User", "Please mention a user.")] }); return; }
    const reason = args.slice(1).join(" ") || "No reason provided";
    await message.guild.members.ban(target.id, { reason }).catch(() => null);
    await message.reply({ embeds: [successEmbed("Banned", `**${target.tag}** has been banned.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
