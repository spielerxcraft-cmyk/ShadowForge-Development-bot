import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserEconomy } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const DAILY_AMOUNT = 500;
const COOLDOWN = 86400000;

const command: PrefixCommand = {
  name: "daily",
  description: "Claim your daily reward",
  async execute(message: Message) {
    const eco = getUserEconomy(message.author.id);
    const now = Date.now();
    if (eco.daily > 0 && now - eco.daily < COOLDOWN) {
      const remaining = eco.daily + COOLDOWN - now;
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      await message.reply({ embeds: [new EmbedBuilder().setColor(Colors.error as ColorResolvable).setDescription(`❌ You can claim again in **${hours}h ${minutes}m**.`)] });
      return;
    }
    eco.balance += DAILY_AMOUNT;
    eco.daily = now;
    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle("🎁 Daily Reward!")
      .setDescription(`You received **${DAILY_AMOUNT} coins**!\n\n💰 **Balance:** ${eco.balance} coins`)
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
