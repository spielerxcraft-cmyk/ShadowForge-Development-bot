import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "help",
  aliases: ["h", "commands"],
  description: "Show all commands",
  async execute(message: Message, args: string[], client: Client) {
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle("🤖 ShadowForge Development Bot — Prefix Commands")
      .setDescription("**Prefix:** `.` — All commands also available as `/` slash commands!\n\nUse `.help <command>` for details on a specific command.")
      .addFields(
        { name: "🔧 Utility", value: "`.ping` `.help` `.avatar` `.userinfo` `.serverinfo` `.poll`" },
        { name: "🏆 Rewards", value: "`.rank` `.balance` `.daily`" },
        { name: "⚔️ Moderation", value: "`.warn` `.ban` `.kick` `.purge` `.warnings`" },
        { name: "💡 Tip", value: "Slash commands (`/`) have more features and options!" },
      )
      .setFooter({ text: `ShadowForge Development • Prefix: . • ${client.user?.tag}` })
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
