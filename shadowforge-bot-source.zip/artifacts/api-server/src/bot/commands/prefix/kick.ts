import type { Message, Client } from "discord.js";
import { PermissionFlagsBits } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "kick",
  description: "Kick a member",
  usage: ".kick @user [reason]",
  async execute(message: Message, args: string[]) {
    if (!message.guild || !message.member) return;
    if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      await message.reply({ embeds: [errorEmbed("No Permission", "You need Kick Members permission.")] }); return;
    }
    const target = message.mentions.users.first();
    if (!target) { await message.reply({ embeds: [errorEmbed("No User", "Please mention a user.")] }); return; }
    const reason = args.slice(1).join(" ") || "No reason provided";
    const member = await message.guild.members.fetch(target.id).catch(() => null);
    if (!member?.kickable) { await message.reply({ embeds: [errorEmbed("Cannot Kick", "I cannot kick this user.")] }); return; }
    await member.kick(reason);
    await message.reply({ embeds: [successEmbed("Kicked", `**${target.tag}** has been kicked.\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
