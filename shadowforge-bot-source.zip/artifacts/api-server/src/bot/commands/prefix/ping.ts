import type { Message, Client } from "discord.js";
import { shadowforgeEmbed } from "../../utils/embeds.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "ping",
  aliases: ["latency"],
  description: "Check bot latency",
  async execute(message: Message, _args: string[], client: Client) {
    const sent = await message.reply({ embeds: [shadowforgeEmbed("🏓 Pinging...")] });
    const latency = sent.createdTimestamp - message.createdTimestamp;
    await sent.edit({
      embeds: [
        shadowforgeEmbed("🏓 Pong!")
          .addFields(
            { name: "Message Latency", value: `${latency}ms`, inline: true },
            { name: "API Latency", value: `${Math.round(client.ws.ping)}ms`, inline: true },
          ),
      ],
    });
  },
};
export default command;
