import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "poll",
  description: "Create a quick yes/no poll",
  usage: ".poll <question>",
  async execute(message: Message, args: string[]) {
    const question = args.join(" ");
    if (!question) { await message.reply("❌ Please provide a question! Usage: `.poll <question>`"); return; }
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`📊 ${question}`)
      .setDescription("👍 Yes\n👎 No")
      .setFooter({ text: `Poll by ${message.author.tag}` })
      .setTimestamp();
    const msg = await message.channel.send({ embeds: [embed] });
    await msg.react("👍");
    await msg.react("👎");
    await message.delete().catch(() => null);
  },
};
export default command;
