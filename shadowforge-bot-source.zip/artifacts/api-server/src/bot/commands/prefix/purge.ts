import type { Message, Client } from "discord.js";
import { PermissionFlagsBits, type TextChannel } from "discord.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "purge",
  aliases: ["clear", "prune"],
  description: "Delete messages",
  usage: ".purge <amount> [@user]",
  async execute(message: Message, args: string[]) {
    if (!message.guild || !message.member) return;
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      await message.reply({ embeds: [errorEmbed("No Permission", "You need Manage Messages permission.")] }); return;
    }
    const amount = parseInt(args[0] ?? "0");
    if (isNaN(amount) || amount < 1 || amount > 100) {
      await message.reply({ embeds: [errorEmbed("Invalid", "Please provide a number between 1 and 100.")] }); return;
    }
    const filterUser = message.mentions.users.first();
    const messages = await message.channel.messages.fetch({ limit: amount + 1 });
    const toDelete = filterUser ? messages.filter((m) => m.author.id === filterUser.id) : messages;
    const deleted = await (message.channel as TextChannel).bulkDelete(toDelete, true);
    const reply = await message.channel.send({ embeds: [successEmbed("Purged", `Deleted **${deleted.size}** messages.`)] });
    setTimeout(() => reply.delete().catch(() => null), 4000);
  },
};
export default command;
