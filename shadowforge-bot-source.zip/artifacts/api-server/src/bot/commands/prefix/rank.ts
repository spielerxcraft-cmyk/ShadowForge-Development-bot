import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserLevel, getXpForLevel } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "rank",
  aliases: ["level", "xp"],
  description: "View your rank",
  async execute(message: Message, args: string[], client: Client) {
    if (!message.guild) return;
    const target = message.mentions.users.first() ?? message.author;
    const key = `${message.guild.id}-${target.id}`;
    const data = getUserLevel(key);
    const needed = getXpForLevel(data.level + 1);
    const progress = Math.round((data.xp / needed) * 20);
    const bar = "█".repeat(progress) + "░".repeat(20 - progress);
    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle(`📊 Rank — ${target.username}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: "Level", value: `**${data.level}**`, inline: true },
        { name: "XP", value: `**${data.xp}** / ${needed}`, inline: true },
        { name: "Messages", value: `**${data.messages}**`, inline: true },
        { name: "Progress", value: `\`[${bar}]\` ${Math.round((data.xp / needed) * 100)}%` },
      )
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
