import type { Message, Client } from "discord.js";
import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "userinfo",
  aliases: ["ui", "whois"],
  description: "Get user information",
  async execute(message: Message, args: string[], client: Client) {
    if (!message.guild) return;
    const target = message.mentions.users.first() ?? message.author;
    const member = await message.guild.members.fetch(target.id).catch(() => null);
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`👤 ${target.username}`)
      .setThumbnail(target.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: "ID", value: target.id, inline: true },
        { name: "Tag", value: target.tag, inline: true },
        { name: "Bot", value: target.bot ? "Yes" : "No", inline: true },
        { name: "Account Created", value: `<t:${Math.floor(target.createdTimestamp / 1000)}:F>`, inline: true },
        ...(member ? [{ name: "Joined Server", value: `<t:${Math.floor((member.joinedTimestamp ?? 0) / 1000)}:F>`, inline: true }] : []),
      )
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
