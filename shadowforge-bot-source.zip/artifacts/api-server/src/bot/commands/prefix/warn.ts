import type { Message, Client } from "discord.js";
import { PermissionFlagsBits } from "discord.js";
import { addWarning } from "../../systems/database.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "warn",
  description: "Warn a member",
  usage: ".warn @user <reason>",
  async execute(message: Message, args: string[]) {
    if (!message.guild || !message.member) return;
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      await message.reply({ embeds: [errorEmbed("No Permission", "You need Manage Messages permission.")] }); return;
    }
    const target = message.mentions.users.first();
    if (!target) { await message.reply({ embeds: [errorEmbed("No User", "Please mention a user.")] }); return; }
    const reason = args.slice(1).join(" ") || "No reason provided";
    const count = addWarning(message.guild.id, target.id, reason, message.author.id);
    await message.reply({ embeds: [successEmbed("Warned", `${target} has been warned. (${count} total)\n\n**Reason:** ${reason}`)] });
  },
};
export default command;
