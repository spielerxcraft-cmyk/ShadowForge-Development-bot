import type { Message, Client } from "discord.js";
import { PermissionFlagsBits, EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserWarnings } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import { errorEmbed } from "../../utils/embeds.js";
import type { PrefixCommand } from "../../handlers/commandHandler.js";

const command: PrefixCommand = {
  name: "warnings",
  aliases: ["warns", "infractions"],
  description: "View warnings for a user",
  usage: ".warnings @user",
  async execute(message: Message, args: string[]) {
    if (!message.guild || !message.member) return;
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      await message.reply({ embeds: [errorEmbed("No Permission", "You need Manage Messages permission.")] }); return;
    }
    const target = message.mentions.users.first() ?? message.author;
    const warns = getUserWarnings(message.guild.id, target.id);
    if (warns.length === 0) { await message.reply({ embeds: [errorEmbed("No Warnings", `${target.tag} has no warnings.`)] }); return; }
    const embed = new EmbedBuilder()
      .setColor(Colors.warning as ColorResolvable)
      .setTitle(`⚠️ Warnings — ${target.tag}`)
      .setDescription(warns.map((w, i) => `**#${i + 1}** — ${w.reason}\nBy <@${w.moderator}> • <t:${Math.floor(w.timestamp / 1000)}:R>`).join("\n\n"))
      .setFooter({ text: `Total: ${warns.length}` })
      .setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
export default command;
