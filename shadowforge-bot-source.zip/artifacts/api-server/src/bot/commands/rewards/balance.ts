import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserEconomy } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your coin balance")
    .addUserOption((o) => o.setName("user").setDescription("User to check").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user") ?? interaction.user;
    const eco = getUserEconomy(target.id);
    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle(`💰 Balance — ${target.username}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: "Coins", value: `**${eco.balance}** 🪙`, inline: true },
        { name: "Reputation", value: `**${eco.reputation}** ⭐`, inline: true },
        { name: "Badges", value: eco.badges.length > 0 ? eco.badges.join(" ") : "None", inline: true },
      )
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
