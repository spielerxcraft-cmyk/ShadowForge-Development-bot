import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserEconomy } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import { errorEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const DAILY_AMOUNT = 500;
const COOLDOWN = 86400000;

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("daily")
    .setDescription("Claim your daily reward"),
  async execute(interaction: ChatInputCommandInteraction) {
    const eco = getUserEconomy(interaction.user.id);
    const now = Date.now();
    if (eco.daily > 0 && now - eco.daily < COOLDOWN) {
      const remaining = eco.daily + COOLDOWN - now;
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      await interaction.reply({ embeds: [errorEmbed("Already Claimed", `You can claim your next daily reward in **${hours}h ${minutes}m**.`)], ephemeral: true });
      return;
    }
    eco.balance += DAILY_AMOUNT;
    eco.daily = now;
    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle("🎁 Daily Reward Claimed!")
      .setDescription(`You received **${DAILY_AMOUNT} coins**!\n\n💰 **Balance:** ${eco.balance} coins`)
      .setFooter({ text: "Come back tomorrow for more!" })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
