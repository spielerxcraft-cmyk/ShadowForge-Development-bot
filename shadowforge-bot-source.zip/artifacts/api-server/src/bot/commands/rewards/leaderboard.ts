import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { levels } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("View the server leaderboard")
    .addStringOption((o) =>
      o.setName("type").setDescription("Type of leaderboard").setRequired(false)
        .addChoices({ name: "XP/Levels", value: "xp" }, { name: "Economy", value: "economy" })
    ),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const type = interaction.options.getString("type") ?? "xp";

    const guildPrefix = `${interaction.guild.id}-`;
    const guildEntries = [...levels.entries()]
      .filter(([k]) => k.startsWith(guildPrefix))
      .map(([k, v]) => ({ userId: k.replace(guildPrefix, ""), ...v }))
      .sort((a, b) => b.level !== a.level ? b.level - a.level : b.xp - a.xp)
      .slice(0, 10);

    const medals = ["🥇", "🥈", "🥉"];
    const description = guildEntries.length === 0
      ? "No data yet! Start chatting to earn XP."
      : guildEntries.map((e, i) => `${medals[i] ?? `**${i + 1}.**`} <@${e.userId}> — Level **${e.level}** (${e.xp} XP)`).join("\n");

    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle("🏆 Server Leaderboard")
      .setDescription(description)
      .setFooter({ text: "ShadowForge Level System" })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
