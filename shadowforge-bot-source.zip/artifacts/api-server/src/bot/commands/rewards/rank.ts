import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserLevel, getXpForLevel } from "../../systems/database.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("rank")
    .setDescription("View your rank or another member's")
    .addUserOption((o) => o.setName("user").setDescription("User to check").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user") ?? interaction.user;
    if (!interaction.guild) return;
    const key = `${interaction.guild.id}-${target.id}`;
    const data = getUserLevel(key);
    const needed = getXpForLevel(data.level + 1);
    const progress = Math.round((data.xp / needed) * 20);
    const bar = "█".repeat(progress) + "░".repeat(20 - progress);

    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle(`📊 Rank — ${target.username}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: "Level", value: `**${data.level}**`, inline: true },
        { name: "XP", value: `**${data.xp}** / ${needed}`, inline: true },
        { name: "Messages", value: `**${data.messages}**`, inline: true },
        { name: "Progress", value: `\`[${bar}]\` ${Math.round((data.xp / needed) * 100)}%` },
      )
      .setFooter({ text: "ShadowForge Level System" })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
