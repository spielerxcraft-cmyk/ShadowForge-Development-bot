import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { getGuildConfig } from "../../systems/database.js";
import { successEmbed } from "../../utils/embeds.js";
import { shadowforgeEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("security")
    .setDescription("Manage security settings")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName("status").setDescription("View current security settings"))
    .addSubcommand((s) =>
      s.setName("toggle").setDescription("Toggle a security module")
        .addStringOption((o) =>
          o.setName("module").setDescription("Module to toggle").setRequired(true)
            .addChoices(
              { name: "Anti Spam", value: "antiSpam" },
              { name: "Anti Raid", value: "antiRaid" },
              { name: "Anti Link", value: "antiLink" },
              { name: "Anti Scam", value: "antiScam" },
              { name: "Anti Mass Mention", value: "antiMassMention" },
              { name: "Anti Invite Links", value: "antiInvite" },
            )
        )
    )
    .addSubcommand((s) =>
      s.setName("config").setDescription("Configure security thresholds")
        .addIntegerOption((o) => o.setName("max_mentions").setDescription("Max mentions before action (default 5)").setMinValue(1).setMaxValue(20))
        .addIntegerOption((o) => o.setName("spam_threshold").setDescription("Messages per 5s before mute (default 5)").setMinValue(3).setMaxValue(15))
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();
    const config = getGuildConfig(interaction.guild.id);

    if (sub === "status") {
      const embed = shadowforgeEmbed("🛡️ Security Status")
        .addFields(
          { name: "Anti Spam", value: config.antiSpam ? "✅ Enabled" : "❌ Disabled", inline: true },
          { name: "Anti Raid", value: config.antiRaid ? "✅ Enabled" : "❌ Disabled", inline: true },
          { name: "Anti Link", value: config.antiLink ? "✅ Enabled" : "❌ Disabled", inline: true },
          { name: "Anti Scam", value: config.antiScam ? "✅ Enabled" : "❌ Disabled", inline: true },
          { name: "Anti Mass Mention", value: config.antiMassMention ? "✅ Enabled" : "❌ Disabled", inline: true },
          { name: "Anti Invite Links", value: config.antiInvite ? "✅ Enabled" : "❌ Disabled", inline: true },
          { name: "Max Mentions", value: `${config.maxMentions}`, inline: true },
          { name: "Spam Threshold", value: `${config.spamThreshold} msg/5s`, inline: true },
        );
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (sub === "toggle") {
      const module = interaction.options.getString("module", true) as keyof typeof config;
      (config as Record<string, unknown>)[module] = !(config as Record<string, unknown>)[module];
      const enabled = (config as Record<string, unknown>)[module] as boolean;
      await interaction.reply({ embeds: [successEmbed("Security Updated", `**${module}** has been ${enabled ? "✅ enabled" : "❌ disabled"}.`)] });
      return;
    }

    if (sub === "config") {
      const maxMentions = interaction.options.getInteger("max_mentions");
      const spamThreshold = interaction.options.getInteger("spam_threshold");
      if (maxMentions) config.maxMentions = maxMentions;
      if (spamThreshold) config.spamThreshold = spamThreshold;
      await interaction.reply({ embeds: [successEmbed("Config Updated", "Security thresholds have been updated.")] });
      return;
    }
  },
};

export default command;
