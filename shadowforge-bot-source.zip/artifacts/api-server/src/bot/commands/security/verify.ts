import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { getVerificationEmbed, getVerificationRow } from "../../systems/verification.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import { getGuildConfig } from "../../systems/database.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("verify")
    .setDescription("Verification system")
    .addSubcommand((s) => s.setName("panel").setDescription("Send verification panel"))
    .addSubcommand((s) =>
      s.setName("setrole").setDescription("Set the verification role")
        .addRoleOption((o) => o.setName("role").setDescription("Role to give on verify").setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();

    if (sub === "panel") {
      await interaction.channel!.send({ embeds: [getVerificationEmbed()], components: [getVerificationRow()] });
      await interaction.reply({ embeds: [successEmbed("Panel Sent", "Verification panel has been sent.")], ephemeral: true });
    }

    if (sub === "setrole") {
      const role = interaction.options.getRole("role", true);
      const config = getGuildConfig(interaction.guild.id);
      config.verifyRole = role.id;
      await interaction.reply({ embeds: [successEmbed("Role Set", `Verified members will receive ${role}.`)] });
    }
  },
};

export default command;
