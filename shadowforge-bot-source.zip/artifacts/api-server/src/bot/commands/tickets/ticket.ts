import {
  SlashCommandBuilder, type ChatInputCommandInteraction,
  PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
} from "discord.js";
import { getTicketPanelEmbed } from "../../systems/tickets.js";
import { createTicket, closeTicket } from "../../systems/tickets.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";
import { successEmbed, errorEmbed } from "../../utils/embeds.js";
import { tickets } from "../../systems/database.js";
import type { TicketType } from "../../systems/tickets.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Ticket system management")
    .addSubcommand((s) => s.setName("panel").setDescription("Send the ticket panel"))
    .addSubcommand((s) =>
      s.setName("create").setDescription("Create a ticket")
        .addStringOption((o) => o.setName("type").setDescription("Ticket type").setRequired(true)
          .addChoices(
            { name: "Support", value: "support" },
            { name: "Purchase", value: "purchase" },
            { name: "Partnership", value: "partnership" },
            { name: "Report", value: "report" },
            { name: "Application", value: "application" },
          ))
    )
    .addSubcommand((s) => s.setName("close").setDescription("Close the current ticket"))
    .addSubcommand((s) =>
      s.setName("add").setDescription("Add a user to the ticket")
        .addUserOption((o) => o.setName("user").setDescription("User to add").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("remove").setDescription("Remove a user from the ticket")
        .addUserOption((o) => o.setName("user").setDescription("User to remove").setRequired(true))
    )
    .addSubcommand((s) => s.setName("rename").setDescription("Rename the ticket channel")
      .addStringOption((o) => o.setName("name").setDescription("New name").setRequired(true))
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();

    if (sub === "panel") {
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ticket_support").setLabel("Support").setStyle(ButtonStyle.Primary).setEmoji("🛠️"),
        new ButtonBuilder().setCustomId("ticket_purchase").setLabel("Purchase").setStyle(ButtonStyle.Success).setEmoji("💰"),
        new ButtonBuilder().setCustomId("ticket_partnership").setLabel("Partnership").setStyle(ButtonStyle.Secondary).setEmoji("🤝"),
        new ButtonBuilder().setCustomId("ticket_report").setLabel("Report").setStyle(ButtonStyle.Danger).setEmoji("🚨"),
        new ButtonBuilder().setCustomId("ticket_application").setLabel("Application").setStyle(ButtonStyle.Secondary).setEmoji("📋"),
      );
      await interaction.channel!.send({ embeds: [getTicketPanelEmbed()], components: [row] });
      await interaction.reply({ embeds: [successEmbed("Panel Sent", "Ticket panel has been sent.")], ephemeral: true });
      return;
    }

    if (sub === "create") {
      const type = interaction.options.getString("type", true) as TicketType;
      const channel = await createTicket(interaction.guild, interaction.user, type);
      if (!channel) {
        await interaction.reply({ embeds: [errorEmbed("Already Open", "You already have an open ticket.")], ephemeral: true });
        return;
      }
      await interaction.reply({ embeds: [successEmbed("Ticket Created", `Your ticket has been created: ${channel}`)], ephemeral: true });
      return;
    }

    if (sub === "close") {
      const { TextChannel } = await import("discord.js");
      if (!(interaction.channel instanceof TextChannel)) return;
      const ticket = tickets.get(interaction.channel.id);
      if (!ticket) { await interaction.reply({ embeds: [errorEmbed("Not a Ticket", "This command can only be used inside a ticket.")], ephemeral: true }); return; }
      await interaction.reply({ embeds: [successEmbed("Closing...", "This ticket is being closed.")] });
      await closeTicket(interaction.channel);
      return;
    }

    if (sub === "add") {
      const user = interaction.options.getUser("user", true);
      await interaction.channel!.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true });
      await interaction.reply({ embeds: [successEmbed("User Added", `${user} has been added to this ticket.`)] });
      return;
    }

    if (sub === "remove") {
      const user = interaction.options.getUser("user", true);
      await interaction.channel!.permissionOverwrites.edit(user.id, { ViewChannel: false });
      await interaction.reply({ embeds: [successEmbed("User Removed", `${user} has been removed from this ticket.`)] });
      return;
    }

    if (sub === "rename") {
      const name = interaction.options.getString("name", true);
      await interaction.channel!.setName(name);
      await interaction.reply({ embeds: [successEmbed("Renamed", `Channel renamed to **${name}**.`)] });
      return;
    }
  },
};

export default command;
