import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("avatar")
    .setDescription("Get a user's avatar")
    .addUserOption((o) => o.setName("user").setDescription("User to get avatar of").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user") ?? interaction.user;
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`🖼️ ${target.username}'s Avatar`)
      .setImage(target.displayAvatarURL({ size: 4096 }))
      .addFields(
        { name: "PNG", value: `[Link](${target.displayAvatarURL({ size: 4096, extension: "png" })})`, inline: true },
        { name: "JPG", value: `[Link](${target.displayAvatarURL({ size: 4096, extension: "jpg" })})`, inline: true },
        { name: "WebP", value: `[Link](${target.displayAvatarURL({ size: 4096, extension: "webp" })})`, inline: true },
      )
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
