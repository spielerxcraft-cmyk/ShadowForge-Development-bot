import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
  type ColorResolvable,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  type StringSelectMenuInteraction,
  ComponentType,
} from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const categories: Record<
  string,
  { emoji: string; label: string; desc: string; color: number; commands: { name: string; desc: string; usage?: string }[] }
> = {
  security: {
    emoji: "🛡️",
    label: "Security",
    desc: "Keep your server safe from raiders, spammers, scammers, and bad actors.",
    color: Colors.error,
    commands: [
      { name: "/security status", desc: "View all active security settings" },
      { name: "/security toggle <module>", desc: "Enable or disable a security module (anti-spam, anti-raid, anti-link, anti-scam, anti-mention, anti-invite)" },
      { name: "/security config", desc: "Configure max mentions and spam thresholds" },
      { name: "/verify panel", desc: "Send the verification button panel" },
      { name: "/verify setrole <role>", desc: "Set the role given on verification" },
    ],
  },
  welcome: {
    emoji: "👋",
    label: "Welcome System",
    desc: "Greet new members and say goodbye with beautiful embeds.",
    color: Colors.success,
    commands: [
      { name: "/welcome setchannel <channel>", desc: "Set the welcome message channel" },
      { name: "/welcome setgoodbye <channel>", desc: "Set the goodbye message channel" },
      { name: "/welcome setmessage <msg>", desc: "Custom welcome message ({user} {server} {count})" },
      { name: "/welcome setautorole <role>", desc: "Auto-assign a role to every new member" },
      { name: "/welcome status", desc: "View current welcome configuration" },
    ],
  },
  tickets: {
    emoji: "🎫",
    label: "Ticket System",
    desc: "Full-featured support ticketing with 5 ticket types, transcripts, and more.",
    color: Colors.shadowforge,
    commands: [
      { name: "/ticket panel", desc: "Send the ticket selection panel (5 types)" },
      { name: "/ticket create <type>", desc: "Manually create a ticket (support/purchase/partnership/report/application)" },
      { name: "/ticket close", desc: "Close the current ticket channel" },
      { name: "/ticket add <user>", desc: "Add a user to the current ticket" },
      { name: "/ticket remove <user>", desc: "Remove a user from the current ticket" },
      { name: "/ticket rename <name>", desc: "Rename the current ticket channel" },
    ],
  },
  moderation: {
    emoji: "⚔️",
    label: "Moderation",
    desc: "Full moderation toolkit — warn, ban, kick, mute, purge, and more.",
    color: Colors.warning,
    commands: [
      { name: "/warn <user> <reason>", desc: "Issue a warning to a member" },
      { name: "/warnings <user>", desc: "View all warnings for a member" },
      { name: "/ban <user> [reason] [days]", desc: "Ban a member, optionally delete message history" },
      { name: "/kick <user> [reason]", desc: "Kick a member from the server" },
      { name: "/timeout <user> <minutes> [reason]", desc: "Timeout a member" },
      { name: "/unban <user_id> [reason]", desc: "Unban a previously banned user" },
      { name: "/purge <amount> [user]", desc: "Bulk delete messages (1–100), optionally by user" },
      { name: "/slowmode <seconds>", desc: "Set channel slowmode (0 to disable)" },
      { name: "/lock <lock|unlock> [reason]", desc: "Lock or unlock a channel" },
    ],
  },
  giveaway: {
    emoji: "🎉",
    label: "Giveaways",
    desc: "Host giveaways with button entry, requirements, reroll, and auto-end.",
    color: Colors.gold,
    commands: [
      { name: "/giveaway start <prize> <duration> <winners> [requirements]", desc: "Start a giveaway" },
      { name: "/giveaway end <message_id>", desc: "End a giveaway early and pick winners" },
      { name: "/giveaway reroll <message_id>", desc: "Reroll and pick a new winner" },
      { name: "/giveaway list", desc: "List all active giveaways in this server" },
    ],
  },
  rewards: {
    emoji: "🏆",
    label: "Rewards & Economy",
    desc: "Level system, XP, economy, leaderboard, daily rewards, and badges.",
    color: Colors.gold,
    commands: [
      { name: "/rank [user]", desc: "View your rank card with XP progress bar" },
      { name: "/leaderboard", desc: "View the server XP leaderboard (top 10)" },
      { name: "/daily", desc: "Claim your daily 500 coin reward (24h cooldown)" },
      { name: "/balance [user]", desc: "Check your coin balance and reputation" },
    ],
  },
  invites: {
    emoji: "📨",
    label: "Invite Tracking",
    desc: "Track who invited who, detect fake invites, and reward top inviters.",
    color: Colors.info,
    commands: [
      { name: "/invites check [user]", desc: "View invite stats for a user (total, fake, valid)" },
      { name: "/invites leaderboard", desc: "View the server invite leaderboard" },
      { name: "/invites add <user> <amount>", desc: "Manually add bonus invites to a user" },
    ],
  },
  announcements: {
    emoji: "📢",
    label: "Announcements",
    desc: "Send professional announcements, schedule messages, and ping roles.",
    color: Colors.primary,
    commands: [
      { name: "/announce send <title> <message> [channel] [ping] [color]", desc: "Send a rich embed announcement" },
      { name: "/announce plain <message> [channel] [ping]", desc: "Send a plain text announcement" },
      { name: "/announce schedule <message> <minutes> [channel]", desc: "Schedule an announcement to send later" },
    ],
  },
  ai: {
    emoji: "🤖",
    label: "AI Features",
    desc: "AI-powered chat, FAQ answering, text summarization, and translation.",
    color: Colors.purple,
    commands: [
      { name: "/ai chat <message>", desc: "Chat with the ShadowForge AI assistant" },
      { name: "/ai faq <question>", desc: "Get instant answers to common questions" },
      { name: "/ai translate <text> <language>", desc: "Translate text to another language" },
      { name: "/ai summarize <text>", desc: "Summarize a long piece of text" },
    ],
  },
  utility: {
    emoji: "🔧",
    label: "Utility",
    desc: "Handy tools — user info, server info, polls, avatar, role info, website button, and more.",
    color: Colors.shadowforge,
    commands: [
      { name: "/userinfo [user]", desc: "View detailed info about a user" },
      { name: "/serverinfo", desc: "View detailed info about this server" },
      { name: "/avatar [user]", desc: "Get a user's avatar in full quality" },
      { name: "/roleinfo <role>", desc: "View detailed info about a role" },
      { name: "/poll <question> <opt1> <opt2> [opt3-5]", desc: "Create a multi-option poll (up to 5 options)" },
      { name: "/website set <url> [label] [description] [emoji]", desc: "Set your server's website link from Discord" },
      { name: "/website panel [channel]", desc: "Send a clickable website button panel to a channel" },
      { name: "/website status", desc: "Preview the current website button configuration" },
      { name: "/website remove", desc: "Remove the website configuration" },
      { name: "/help [category]", desc: "Show this help panel" },
    ],
  },
  owner: {
    emoji: "👑",
    label: "Owner / Admin",
    desc: "Server owner and admin tools — modules, maintenance, stats, and backup.",
    color: Colors.gold,
    commands: [
      { name: "/owner status", desc: "View full bot status (ping, memory, guilds, uptime)" },
      { name: "/owner module <module> <enabled>", desc: "Enable or disable a bot module" },
      { name: "/owner maintenance <enabled>", desc: "Toggle maintenance mode" },
      { name: "/owner backup", desc: "Create a guild configuration backup" },
      { name: "/owner stats", desc: "View detailed server statistics" },
    ],
  },
  prefix: {
    emoji: "⌨️",
    label: "Prefix Commands",
    desc: "All prefix commands using the `.` prefix (e.g. `.help`, `.rank`).",
    color: Colors.dark,
    commands: [
      { name: ".help [command]", desc: "Show prefix command list" },
      { name: ".ping", desc: "Check bot latency (aliases: latency)" },
      { name: ".rank [@user]", desc: "View rank card (aliases: level, xp)" },
      { name: ".balance [@user]", desc: "View coin balance (aliases: bal, coins, money)" },
      { name: ".daily", desc: "Claim daily coin reward" },
      { name: ".userinfo [@user]", desc: "User information (aliases: ui, whois)" },
      { name: ".serverinfo", desc: "Server information (aliases: si, server)" },
      { name: ".avatar [@user]", desc: "Get avatar (aliases: av, pfp)" },
      { name: ".poll <question>", desc: "Quick yes/no poll" },
      { name: ".warn @user [reason]", desc: "Warn a member (requires Manage Messages)" },
      { name: ".ban @user [reason]", desc: "Ban a member (requires Ban Members)" },
      { name: ".kick @user [reason]", desc: "Kick a member (requires Kick Members)" },
      { name: ".purge <amount> [@user]", desc: "Bulk delete messages (aliases: clear, prune)" },
      { name: ".warnings [@user]", desc: "View warnings (aliases: warns, infractions)" },
    ],
  },
};

const totalCommands = Object.values(categories).reduce((a, c) => a + c.commands.length, 0);

function buildMainEmbed(client: import("discord.js").Client): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.shadowforge as ColorResolvable)
    .setAuthor({
      name: "ShadowForge Development Bot",
      iconURL: client.user?.displayAvatarURL(),
    })
    .setTitle("🤖 Command Help Panel")
    .setDescription(
      `**Powering ShadowForge Development with Professional Automation.**\n\n` +
      `Use the **dropdown below** to browse command categories.\n\n` +
      `> 📌 Slash commands: Use \`/\` to see all commands\n` +
      `> ⌨️ Prefix commands: Use \`.\` before any command\n` +
      `> 🎫 Need help? Open a ticket with \`/ticket create support\``,
    )
    .addFields(
      Object.entries(categories).map(([, cat]) => ({
        name: `${cat.emoji} ${cat.label}`,
        value: `${cat.commands.length} command${cat.commands.length !== 1 ? "s" : ""}`,
        inline: true,
      }))
    )
    .setFooter({
      text: `ShadowForge Development • ${totalCommands} total commands • Prefix: .`,
      iconURL: client.user?.displayAvatarURL(),
    })
    .setTimestamp();
}

function buildCategoryEmbed(key: string, client: import("discord.js").Client): EmbedBuilder {
  const cat = categories[key]!;
  const cmdList = cat.commands
    .map((c) => `> **\`${c.name}\`**\n> ${c.desc}`)
    .join("\n\n");

  return new EmbedBuilder()
    .setColor(cat.color as ColorResolvable)
    .setAuthor({
      name: "ShadowForge Development Bot",
      iconURL: client.user?.displayAvatarURL(),
    })
    .setTitle(`${cat.emoji} ${cat.label} Commands`)
    .setDescription(`${cat.desc}\n\n${cmdList}`)
    .setFooter({
      text: `ShadowForge Development • ${cat.commands.length} commands in this category • Use dropdown to switch`,
      iconURL: client.user?.displayAvatarURL(),
    })
    .setTimestamp();
}

function buildSelectMenu(): ActionRowBuilder<StringSelectMenuBuilder> {
  const options = [
    new StringSelectMenuOptionBuilder()
      .setLabel("📋 Overview")
      .setValue("overview")
      .setDescription("See all command categories at a glance")
      .setEmoji("📋"),
    ...Object.entries(categories).map(([key, cat]) =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${cat.label}`)
        .setValue(key)
        .setDescription(`${cat.commands.length} commands — ${cat.desc.slice(0, 50)}...`)
        .setEmoji(cat.emoji),
    ),
  ];

  const menu = new StringSelectMenuBuilder()
    .setCustomId("help_category_select")
    .setPlaceholder("📚 Select a command category...")
    .addOptions(options);

  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
}

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("View all ShadowForge bot commands with the interactive help panel"),

  async execute(interaction: ChatInputCommandInteraction) {
    const mainEmbed = buildMainEmbed(interaction.client);
    const row = buildSelectMenu();

    const reply = await interaction.reply({
      embeds: [mainEmbed],
      components: [row],
      fetchReply: true,
    });

    // Listen for dropdown selection for 3 minutes
    const collector = reply.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      time: 180_000,
      filter: (i) => i.user.id === interaction.user.id,
    });

    collector.on("collect", async (selectInteraction: StringSelectMenuInteraction) => {
      const selected = selectInteraction.values[0];

      if (selected === "overview" || !selected || !categories[selected]) {
        await selectInteraction.update({
          embeds: [buildMainEmbed(interaction.client)],
          components: [buildSelectMenu()],
        });
      } else {
        await selectInteraction.update({
          embeds: [buildCategoryEmbed(selected, interaction.client)],
          components: [buildSelectMenu()],
        });
      }
    });

    collector.on("end", async () => {
      // Disable the menu after timeout
      const disabledMenu = new StringSelectMenuBuilder()
        .setCustomId("help_category_select_disabled")
        .setPlaceholder("⏰ Help panel expired — run /help again")
        .setDisabled(true)
        .addOptions(
          new StringSelectMenuOptionBuilder().setLabel("Expired").setValue("expired"),
        );

      const disabledRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(disabledMenu);
      await reply.edit({ components: [disabledRow] }).catch(() => null);
    });
  },
};

export default command;
