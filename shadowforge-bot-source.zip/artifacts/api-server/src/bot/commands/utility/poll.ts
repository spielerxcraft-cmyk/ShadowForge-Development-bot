import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("poll")
    .setDescription("Create a poll")
    .addStringOption((o) => o.setName("question").setDescription("The poll question").setRequired(true))
    .addStringOption((o) => o.setName("option1").setDescription("Option 1").setRequired(true))
    .addStringOption((o) => o.setName("option2").setDescription("Option 2").setRequired(true))
    .addStringOption((o) => o.setName("option3").setDescription("Option 3").setRequired(false))
    .addStringOption((o) => o.setName("option4").setDescription("Option 4").setRequired(false))
    .addStringOption((o) => o.setName("option5").setDescription("Option 5").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const question = interaction.options.getString("question", true);
    const optionEmojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];
    const options = [1, 2, 3, 4, 5]
      .map((n) => interaction.options.getString(`option${n}`))
      .filter((o): o is string => o !== null);

    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`📊 ${question}`)
      .setDescription(options.map((o, i) => `${optionEmojis[i]} ${o}`).join("\n\n"))
      .setFooter({ text: `Poll by ${interaction.user.tag} • React to vote!` })
      .setTimestamp();

    const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
    for (let i = 0; i < options.length; i++) {
      await msg.react(optionEmojis[i]!);
    }
  },
};
export default command;
