import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("roleinfo")
    .setDescription("Get information about a role")
    .addRoleOption((o) => o.setName("role").setDescription("Role to inspect").setRequired(true)),
  async execute(interaction: ChatInputCommandInteraction) {
    const role = interaction.options.getRole("role", true);
    if (!interaction.guild) return;
    const guildRole = await interaction.guild.roles.fetch(role.id);
    if (!guildRole) return;
    const embed = new EmbedBuilder()
      .setColor((guildRole.color || Colors.shadowforge) as ColorResolvable)
      .setTitle(`🎭 Role: ${guildRole.name}`)
      .addFields(
        { name: "ID", value: guildRole.id, inline: true },
        { name: "Color", value: guildRole.hexColor, inline: true },
        { name: "Position", value: `${guildRole.position}`, inline: true },
        { name: "Members", value: `${guildRole.members.size}`, inline: true },
        { name: "Mentionable", value: guildRole.mentionable ? "Yes" : "No", inline: true },
        { name: "Hoisted", value: guildRole.hoist ? "Yes" : "No", inline: true },
        { name: "Created", value: `<t:${Math.floor(guildRole.createdTimestamp / 1000)}:F>` },
      )
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
