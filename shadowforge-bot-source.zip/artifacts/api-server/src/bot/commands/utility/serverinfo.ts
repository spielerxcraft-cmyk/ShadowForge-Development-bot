import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("Get information about this server"),
  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const guild = interaction.guild;
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`🌐 ${guild.name}`)
      .setThumbnail(guild.iconURL({ size: 256 }) ?? null)
      .addFields(
        { name: "Owner", value: `<@${guild.ownerId}>`, inline: true },
        { name: "ID", value: guild.id, inline: true },
        { name: "Created", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
        { name: "Members", value: `**${guild.memberCount}** total`, inline: true },
        { name: "Channels", value: `**${guild.channels.cache.size}** total`, inline: true },
        { name: "Roles", value: `**${guild.roles.cache.size}** total`, inline: true },
        { name: "Boost Level", value: `Level **${guild.premiumTier}**`, inline: true },
        { name: "Boosts", value: `**${guild.premiumSubscriptionCount ?? 0}**`, inline: true },
        { name: "Verification Level", value: `${guild.verificationLevel}`, inline: true },
      )
      .setImage(guild.bannerURL({ size: 1024 }) ?? null)
      .setFooter({ text: "ShadowForge Development" })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
