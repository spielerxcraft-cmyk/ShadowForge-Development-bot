import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder, type ColorResolvable } from "discord.js";
import { Colors } from "../../utils/colors.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Get information about a user")
    .addUserOption((o) => o.setName("user").setDescription("User to inspect").setRequired(false)),
  async execute(interaction: ChatInputCommandInteraction) {
    const target = interaction.options.getUser("user") ?? interaction.user;
    if (!interaction.guild) return;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    const embed = new EmbedBuilder()
      .setColor(Colors.shadowforge as ColorResolvable)
      .setTitle(`👤 ${target.username}`)
      .setThumbnail(target.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: "ID", value: target.id, inline: true },
        { name: "Tag", value: target.tag, inline: true },
        { name: "Bot", value: target.bot ? "Yes" : "No", inline: true },
        { name: "Account Created", value: `<t:${Math.floor(target.createdTimestamp / 1000)}:F>`, inline: true },
        ...(member ? [
          { name: "Joined Server", value: `<t:${Math.floor((member.joinedTimestamp ?? 0) / 1000)}:F>`, inline: true },
          { name: "Nickname", value: member.nickname ?? "None", inline: true },
          { name: "Roles", value: member.roles.cache.filter((r) => r.id !== interaction.guild!.id).map((r) => r.toString()).join(", ") || "None" },
          { name: "Highest Role", value: member.roles.highest.toString(), inline: true },
        ] : []),
      )
      .setFooter({ text: `ShadowForge Development • Requested by ${interaction.user.tag}` })
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
  },
};
export default command;
