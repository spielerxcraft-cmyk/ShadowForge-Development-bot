import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type ColorResolvable,
  PermissionFlagsBits,
} from "discord.js";
import { Colors } from "../../utils/colors.js";
import { successEmbed, errorEmbed, shadowforgeEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";
import { getGuildConfig } from "../../systems/database.js";

// Extend guild config to hold website data
const websiteData = new Map<string, {
  url: string;
  label: string;
  description: string;
  emoji: string;
  color: string;
}>();

function isValidUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("website")
    .setDescription("Manage your server's website button")

    .addSubcommand((s) =>
      s
        .setName("set")
        .setDescription("Set the website link for this server")
        .addStringOption((o) =>
          o.setName("url").setDescription("Your full website URL (e.g. https://shadowforge.dev)").setRequired(true)
        )
        .addStringOption((o) =>
          o.setName("label").setDescription("Button label (default: Visit Website)").setRequired(false)
        )
        .addStringOption((o) =>
          o.setName("description").setDescription("Short description shown in the panel embed").setRequired(false)
        )
        .addStringOption((o) =>
          o.setName("emoji").setDescription("Emoji to show on the button (default: 🌐)").setRequired(false)
        )
    )

    .addSubcommand((s) =>
      s
        .setName("panel")
        .setDescription("Send a clickable website button panel to a channel")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("Channel to send the panel to (default: current)").setRequired(false)
        )
    )

    .addSubcommand((s) =>
      s
        .setName("status")
        .setDescription("View the current website configuration")
    )

    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("Remove the website configuration")
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    // ── SET ──────────────────────────────────────────────
    if (sub === "set") {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        await interaction.reply({ embeds: [errorEmbed("No Permission", "You need **Manage Server** permission to set the website.")], ephemeral: true });
        return;
      }

      const url = interaction.options.getString("url", true).trim();
      const label = interaction.options.getString("label")?.trim() || "Visit Website";
      const description = interaction.options.getString("description")?.trim() || "Click the button below to visit our official website.";
      const emoji = interaction.options.getString("emoji")?.trim() || "🌐";

      if (!isValidUrl(url)) {
        await interaction.reply({
          embeds: [errorEmbed("Invalid URL", "Please provide a valid URL starting with `https://` or `http://`.")],
          ephemeral: true,
        });
        return;
      }

      websiteData.set(guildId, { url, label, description, emoji, color: "shadowforge" });

      const embed = new EmbedBuilder()
        .setColor(Colors.success as ColorResolvable)
        .setTitle("✅ Website Configured!")
        .setDescription(`Your website has been set successfully.\n\nUse \`/website panel\` to send the clickable button to any channel.`)
        .addFields(
          { name: "🔗 URL", value: url, inline: false },
          { name: "🏷️ Button Label", value: `${emoji} ${label}`, inline: true },
          { name: "📝 Description", value: description, inline: false },
        )
        .setFooter({ text: "ShadowForge Development • Website System" })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
      return;
    }

    // ── PANEL ────────────────────────────────────────────
    if (sub === "panel") {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        await interaction.reply({ embeds: [errorEmbed("No Permission", "You need **Manage Server** permission to send the panel.")], ephemeral: true });
        return;
      }

      const data = websiteData.get(guildId);
      if (!data) {
        await interaction.reply({
          embeds: [errorEmbed("Not Configured", "No website is set yet. Use `/website set <url>` first.")],
          ephemeral: true,
        });
        return;
      }

      const targetChannel = interaction.options.getChannel("channel") ?? interaction.channel;
      const channel = await interaction.guild.channels.fetch(targetChannel!.id).catch(() => null);
      if (!channel?.isTextBased()) {
        await interaction.reply({ embeds: [errorEmbed("Invalid Channel", "Could not find a valid text channel.")], ephemeral: true });
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(Colors.shadowforge as ColorResolvable)
        .setTitle(`${data.emoji} ${interaction.guild.name} — Official Website`)
        .setDescription(data.description)
        .setThumbnail(interaction.guild.iconURL({ size: 256 }) ?? null)
        .addFields({ name: "🔗 Link", value: data.url })
        .setFooter({ text: "ShadowForge Development • Click the button below to visit" })
        .setTimestamp();

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setLabel(`${data.emoji} ${data.label}`)
          .setStyle(ButtonStyle.Link)
          .setURL(data.url),
      );

      await (channel as import("discord.js").TextChannel).send({ embeds: [embed], components: [row] });
      await interaction.reply({ embeds: [successEmbed("Panel Sent", `Website button panel sent to ${channel}.`)], ephemeral: true });
      return;
    }

    // ── STATUS ───────────────────────────────────────────
    if (sub === "status") {
      const data = websiteData.get(guildId);
      if (!data) {
        await interaction.reply({
          embeds: [errorEmbed("Not Configured", "No website is set. Use `/website set <url>` to add one.")],
          ephemeral: true,
        });
        return;
      }

      const embed = shadowforgeEmbed("🌐 Website Configuration")
        .addFields(
          { name: "🔗 URL", value: data.url, inline: false },
          { name: "🏷️ Button Label", value: `${data.emoji} ${data.label}`, inline: true },
          { name: "📝 Description", value: data.description, inline: false },
        );

      // Live preview button
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setLabel(`${data.emoji} ${data.label}`)
          .setStyle(ButtonStyle.Link)
          .setURL(data.url),
      );

      await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
      return;
    }

    // ── REMOVE ───────────────────────────────────────────
    if (sub === "remove") {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        await interaction.reply({ embeds: [errorEmbed("No Permission", "You need **Manage Server** permission.")], ephemeral: true });
        return;
      }
      websiteData.delete(guildId);
      await interaction.reply({ embeds: [successEmbed("Removed", "Website configuration has been cleared.")] });
      return;
    }
  },
};

export default command;
