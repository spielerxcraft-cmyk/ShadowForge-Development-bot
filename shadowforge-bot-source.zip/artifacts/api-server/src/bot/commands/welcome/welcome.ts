import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { getGuildConfig } from "../../systems/database.js";
import { successEmbed, shadowforgeEmbed } from "../../utils/embeds.js";
import type { SlashCommand } from "../../handlers/commandHandler.js";

const command: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName("welcome")
    .setDescription("Configure the welcome system")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s.setName("setchannel").setDescription("Set welcome channel")
        .addChannelOption((o) => o.setName("channel").setDescription("Welcome channel").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("setgoodbye").setDescription("Set goodbye channel")
        .addChannelOption((o) => o.setName("channel").setDescription("Goodbye channel").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("setmessage").setDescription("Set welcome message")
        .addStringOption((o) => o.setName("message").setDescription("Message ({user} = mention, {server} = server name, {count} = member count)").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("setautorole").setDescription("Set auto role on join")
        .addRoleOption((o) => o.setName("role").setDescription("Role to auto-assign").setRequired(true))
    )
    .addSubcommand((s) => s.setName("status").setDescription("View welcome config")),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) return;
    const sub = interaction.options.getSubcommand();
    const config = getGuildConfig(interaction.guild.id);

    if (sub === "setchannel") {
      const ch = interaction.options.getChannel("channel", true);
      config.welcomeChannel = ch.id;
      await interaction.reply({ embeds: [successEmbed("Welcome Channel Set", `Welcome messages will be sent to ${ch}.`)] });
    } else if (sub === "setgoodbye") {
      const ch = interaction.options.getChannel("channel", true);
      config.goodbyeChannel = ch.id;
      await interaction.reply({ embeds: [successEmbed("Goodbye Channel Set", `Goodbye messages will be sent to ${ch}.`)] });
    } else if (sub === "setmessage") {
      const msg = interaction.options.getString("message", true);
      config.welcomeMessage = msg;
      await interaction.reply({ embeds: [successEmbed("Message Set", `Welcome message updated:\n\n> ${msg}`)] });
    } else if (sub === "setautorole") {
      const role = interaction.options.getRole("role", true);
      config.autoRole = role.id;
      await interaction.reply({ embeds: [successEmbed("Auto Role Set", `New members will receive ${role}.`)] });
    } else if (sub === "status") {
      const embed = shadowforgeEmbed("👋 Welcome System Config")
        .addFields(
          { name: "Welcome Channel", value: config.welcomeChannel ? `<#${config.welcomeChannel}>` : "Not set", inline: true },
          { name: "Goodbye Channel", value: config.goodbyeChannel ? `<#${config.goodbyeChannel}>` : "Not set", inline: true },
          { name: "Auto Role", value: config.autoRole ? `<@&${config.autoRole}>` : "Not set", inline: true },
          { name: "Message", value: config.welcomeMessage ?? "Default" },
        );
      await interaction.reply({ embeds: [embed] });
    }
  },
};

export default command;
