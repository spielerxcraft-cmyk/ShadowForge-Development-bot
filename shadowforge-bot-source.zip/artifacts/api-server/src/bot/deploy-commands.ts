import { REST, Routes } from "discord.js";
import { botLogger } from "./utils/logger.js";

// Import all slash commands
import warnCmd from "./commands/moderation/warn.js";
import banCmd from "./commands/moderation/ban.js";
import kickCmd from "./commands/moderation/kick.js";
import timeoutCmd from "./commands/moderation/timeout.js";
import unbanCmd from "./commands/moderation/unban.js";
import purgeCmd from "./commands/moderation/purge.js";
import slowmodeCmd from "./commands/moderation/slowmode.js";
import lockCmd from "./commands/moderation/lock.js";
import warningsCmd from "./commands/moderation/warnings.js";
import ticketCmd from "./commands/tickets/ticket.js";
import giveawayCmd from "./commands/giveaway/giveaway.js";
import rankCmd from "./commands/rewards/rank.js";
import leaderboardCmd from "./commands/rewards/leaderboard.js";
import dailyCmd from "./commands/rewards/daily.js";
import balanceCmd from "./commands/rewards/balance.js";
import userinfoCmd from "./commands/utility/userinfo.js";
import serverinfoCmd from "./commands/utility/serverinfo.js";
import avatarCmd from "./commands/utility/avatar.js";
import pollCmd from "./commands/utility/poll.js";
import roleinfoCmd from "./commands/utility/roleinfo.js";
import helpCmd from "./commands/utility/help.js";
import verifyCmd from "./commands/security/verify.js";
import securityCmd from "./commands/security/antiraid.js";
import welcomeCmd from "./commands/welcome/welcome.js";
import announceCmd from "./commands/announcements/announce.js";
import invitesCmd from "./commands/invites/invites.js";
import ownerCmd from "./commands/owner/owner.js";
import aiCmd from "./commands/ai/ai.js";
import websiteCmd from "./commands/utility/website.js";

const commands = [
  warnCmd, banCmd, kickCmd, timeoutCmd, unbanCmd, purgeCmd, slowmodeCmd, lockCmd, warningsCmd,
  ticketCmd, giveawayCmd, rankCmd, leaderboardCmd, dailyCmd, balanceCmd,
  userinfoCmd, serverinfoCmd, avatarCmd, pollCmd, roleinfoCmd, helpCmd, websiteCmd,
  verifyCmd, securityCmd, welcomeCmd, announceCmd, invitesCmd, ownerCmd, aiCmd,
].map((cmd) => cmd.data.toJSON());

export async function deployCommands(): Promise<void> {
  const token = process.env.DISCORD_TOKEN;
  const clientId = process.env.DISCORD_CLIENT_ID;
  const guildId = process.env.DISCORD_GUILD_ID;

  if (!token || !clientId) {
    botLogger.warn("Missing DISCORD_TOKEN or DISCORD_CLIENT_ID — skipping command deployment");
    return;
  }

  const rest = new REST({ version: "10" }).setToken(token);

  try {
    botLogger.info(`Deploying ${commands.length} slash commands...`);

    if (guildId) {
      // Guild commands deploy instantly (good for development)
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      botLogger.info(`✅ Deployed ${commands.length} commands to guild ${guildId}`);
    } else {
      // Global commands take up to 1 hour to propagate
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      botLogger.info(`✅ Deployed ${commands.length} commands globally`);
    }
  } catch (err) {
    botLogger.error(err, "Failed to deploy commands");
  }
}
