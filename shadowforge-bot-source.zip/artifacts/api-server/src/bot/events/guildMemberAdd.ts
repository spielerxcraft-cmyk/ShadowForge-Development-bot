import { Events, type GuildMember, EmbedBuilder, type ColorResolvable, type TextChannel } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { getGuildConfig } from "../systems/database.js";
import { Colors } from "../utils/colors.js";
import { isSuspiciousAccount } from "../systems/verification.js";
import { botLogger } from "../utils/logger.js";

const event: BotEvent = {
  name: Events.GuildMemberAdd,
  async execute(member: GuildMember) {
    const { guild, user } = member;
    const config = getGuildConfig(guild.id);

    // Suspicious account detection
    if (isSuspiciousAccount(user.id, user.createdAt) && config.antiRaid) {
      botLogger.warn({ userId: user.id, guildId: guild.id }, "Suspicious new account detected");
      if (config.logChannel) {
        const logCh = guild.channels.cache.get(config.logChannel) as TextChannel | undefined;
        if (logCh) {
          await logCh.send({
            embeds: [
              new EmbedBuilder()
                .setColor(Colors.warning as ColorResolvable)
                .setTitle("⚠️ Suspicious Account Detected")
                .setDescription(`${user} (${user.tag}) joined with a very new account.`)
                .addFields(
                  { name: "Account Age", value: `${Math.floor((Date.now() - user.createdTimestamp) / 86400000)} days`, inline: true },
                  { name: "User ID", value: user.id, inline: true },
                )
                .setThumbnail(user.displayAvatarURL())
                .setTimestamp(),
            ],
          }).catch(() => null);
        }
      }
    }

    // Auto role
    if (config.autoRole) {
      const role = guild.roles.cache.get(config.autoRole);
      if (role) await member.roles.add(role).catch(() => null);
    }

    // Welcome message
    if (config.welcomeChannel) {
      const ch = guild.channels.cache.get(config.welcomeChannel) as TextChannel | undefined;
      if (ch) {
        const msgTemplate = config.welcomeMessage ?? "Welcome to **{server}**, {user}! You are member #{count}.";
        const msg = msgTemplate
          .replace("{user}", user.toString())
          .replace("{server}", guild.name)
          .replace("{count}", guild.memberCount.toString());

        const embed = new EmbedBuilder()
          .setColor(Colors.success as ColorResolvable)
          .setTitle("👋 Welcome!")
          .setDescription(msg)
          .setThumbnail(user.displayAvatarURL({ size: 256 }))
          .addFields(
            { name: "Account Created", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
            { name: "Member Count", value: `#${guild.memberCount}`, inline: true },
          )
          .setFooter({ text: "ShadowForge Development" })
          .setTimestamp();

        await ch.send({ content: `${user}`, embeds: [embed] }).catch(() => null);
      }
    }

    // DM welcome
    await user.send({
      embeds: [
        new EmbedBuilder()
          .setColor(Colors.shadowforge as ColorResolvable)
          .setTitle(`👋 Welcome to ${guild.name}!`)
          .setDescription(
            `Hey ${user.username}, welcome to **${guild.name}**!\n\n` +
            `• Please read the server rules\n` +
            `• Open a ticket if you need help: use \`.ticket create support\`\n` +
            `• Use \`.help\` to see all available commands\n\n` +
            `We're glad to have you here! 🎉`,
          )
          .setThumbnail(guild.iconURL() ?? null)
          .setFooter({ text: "ShadowForge Development" })
          .setTimestamp(),
      ],
    }).catch(() => null); // DMs may be disabled
  },
};

export default event;
