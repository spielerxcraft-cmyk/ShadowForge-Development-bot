import { Events, type GuildMember, EmbedBuilder, type ColorResolvable, type TextChannel } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { getGuildConfig } from "../systems/database.js";
import { Colors } from "../utils/colors.js";

const event: BotEvent = {
  name: Events.GuildMemberRemove,
  async execute(member: GuildMember) {
    const { guild, user } = member;
    const config = getGuildConfig(guild.id);

    if (!config.goodbyeChannel) return;
    const ch = guild.channels.cache.get(config.goodbyeChannel) as TextChannel | undefined;
    if (!ch) return;

    const embed = new EmbedBuilder()
      .setColor(Colors.error as ColorResolvable)
      .setTitle("👋 Goodbye!")
      .setDescription(`**${user.tag}** has left the server. We'll miss them!`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: "Joined", value: member.joinedAt ? `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>` : "Unknown", inline: true },
        { name: "Members", value: `${guild.memberCount}`, inline: true },
      )
      .setFooter({ text: "ShadowForge Development" })
      .setTimestamp();

    await ch.send({ embeds: [embed] }).catch(() => null);
  },
};

export default event;
