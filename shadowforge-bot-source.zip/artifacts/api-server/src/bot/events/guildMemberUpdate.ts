import { Events, type GuildMember, EmbedBuilder, type ColorResolvable, type TextChannel } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { getGuildConfig } from "../systems/database.js";
import { Colors } from "../utils/colors.js";

const event: BotEvent = {
  name: Events.GuildMemberUpdate,
  async execute(oldMember: GuildMember, newMember: GuildMember) {
    const config = getGuildConfig(newMember.guild.id);
    if (!config.logChannel) return;

    const addedRoles = newMember.roles.cache.filter((r) => !oldMember.roles.cache.has(r.id));
    const removedRoles = oldMember.roles.cache.filter((r) => !newMember.roles.cache.has(r.id));
    const nicknameChanged = oldMember.nickname !== newMember.nickname;

    if (addedRoles.size === 0 && removedRoles.size === 0 && !nicknameChanged) return;

    const logCh = newMember.guild.channels.cache.get(config.logChannel) as TextChannel | undefined;
    if (!logCh) return;

    const embed = new EmbedBuilder()
      .setColor(Colors.info as ColorResolvable)
      .setTitle("👤 Member Updated")
      .setThumbnail(newMember.user.displayAvatarURL())
      .addFields(
        { name: "Member", value: `${newMember.user.tag} (${newMember.id})`, inline: true },
      );

    if (addedRoles.size > 0) embed.addFields({ name: "✅ Roles Added", value: addedRoles.map((r) => r.toString()).join(", ") });
    if (removedRoles.size > 0) embed.addFields({ name: "❌ Roles Removed", value: removedRoles.map((r) => r.toString()).join(", ") });
    if (nicknameChanged) embed.addFields(
      { name: "Old Nickname", value: oldMember.nickname ?? "*none*", inline: true },
      { name: "New Nickname", value: newMember.nickname ?? "*none*", inline: true },
    );

    embed.setTimestamp();
    await logCh.send({ embeds: [embed] }).catch(() => null);
  },
};

export default event;
