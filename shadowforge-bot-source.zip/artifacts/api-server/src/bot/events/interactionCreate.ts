import {
  Events, type Interaction, type ButtonInteraction,
  type StringSelectMenuInteraction,
} from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { handleSlashCommand } from "../handlers/commandHandler.js";
import { createTicket, closeTicket } from "../systems/tickets.js";
import { tickets } from "../systems/database.js";
import { verifyUser, isSuspiciousAccount } from "../systems/verification.js";
import { giveaways } from "../systems/database.js";
import { successEmbed, errorEmbed, warningEmbed } from "../utils/embeds.js";
import { buildGiveawayEmbed } from "../systems/giveaway.js";
import type { TicketType } from "../systems/tickets.js";

const event: BotEvent = {
  name: Events.InteractionCreate,
  async execute(interaction: Interaction) {
    if (interaction.isChatInputCommand()) {
      await handleSlashCommand(interaction);
      return;
    }

    if (interaction.isButton()) {
      await handleButton(interaction);
      return;
    }

    // Ignore select menu interactions — handled by per-reply collectors in help.ts
    if (interaction.isStringSelectMenu()) return;
  },
};

async function handleButton(interaction: ButtonInteraction) {
  const { customId, guild, user } = interaction;

  // Verification
  if (customId === "verify_button") {
    if (!guild) return;
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return;

    if (isSuspiciousAccount(user.id, user.createdAt)) {
      await interaction.reply({
        embeds: [warningEmbed("Suspicious Account", "Your account is too new to verify. Please wait a few days and try again.")],
        ephemeral: true,
      });
      return;
    }

    const verified = await verifyUser(guild, user);
    if (verified) {
      await interaction.reply({
        embeds: [successEmbed("Verified!", "You have been successfully verified and can now access the server.")],
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        embeds: [errorEmbed("Setup Required", "Verification role is not configured. Please contact an admin.")],
        ephemeral: true,
      });
    }
    return;
  }

  // Ticket panel buttons
  const ticketTypes: Record<string, TicketType> = {
    ticket_support: "support",
    ticket_purchase: "purchase",
    ticket_partnership: "partnership",
    ticket_report: "report",
    ticket_application: "application",
  };

  if (customId in ticketTypes && guild) {
    const type = ticketTypes[customId]!;
    await interaction.deferReply({ ephemeral: true });
    const channel = await createTicket(guild, user, type);
    if (!channel) {
      await interaction.editReply({ embeds: [errorEmbed("Already Open", "You already have an open ticket.")] });
    } else {
      await interaction.editReply({ embeds: [successEmbed("Ticket Created", `Your ticket has been created: ${channel}`)] });
    }
    return;
  }

  // Ticket actions
  if (customId === "ticket_close") {
    const ticket = tickets.get(interaction.channel!.id);
    if (!ticket) { await interaction.reply({ embeds: [errorEmbed("Error", "This is not a ticket channel.")], ephemeral: true }); return; }
    await interaction.reply({ embeds: [successEmbed("Closing", "This ticket will be closed in 5 seconds.")] });
    const { TextChannel } = await import("discord.js");
    if (interaction.channel instanceof TextChannel) {
      await closeTicket(interaction.channel);
    }
    return;
  }

  if (customId === "ticket_claim") {
    const ticket = tickets.get(interaction.channel!.id);
    if (!ticket) return;
    if (ticket.claimed) {
      await interaction.reply({ embeds: [errorEmbed("Already Claimed", `This ticket is already claimed by <@${ticket.claimedBy}>.`)], ephemeral: true });
      return;
    }
    ticket.claimed = true;
    ticket.claimedBy = user.id;
    await interaction.reply({ embeds: [successEmbed("Ticket Claimed", `${user} has claimed this ticket.`)] });
    return;
  }

  if (customId === "ticket_transcript") {
    const ticket = tickets.get(interaction.channel!.id);
    if (!ticket) return;
    const content = ticket.transcript.length > 0 ? ticket.transcript.join("\n") : "No messages recorded.";
    await interaction.reply({
      embeds: [successEmbed("Transcript", `Transcript contains ${ticket.transcript.length} messages.`)],
      files: [{ attachment: Buffer.from(content), name: "transcript.txt" }],
      ephemeral: true,
    });
    return;
  }

  // Giveaway
  if (customId === "giveaway_enter") {
    const msg = interaction.message;
    const giveaway = giveaways.get(msg.id);
    if (!giveaway || giveaway.ended) {
      await interaction.reply({ embeds: [errorEmbed("Ended", "This giveaway has already ended.")], ephemeral: true });
      return;
    }
    if (giveaway.entries.includes(user.id)) {
      await interaction.reply({ embeds: [errorEmbed("Already Entered", "You are already entered in this giveaway.")], ephemeral: true });
      return;
    }
    giveaway.entries.push(user.id);
    await interaction.reply({ embeds: [successEmbed("Entered!", `You have entered the giveaway for **${giveaway.prize}**! 🎉`)], ephemeral: true });
    const embed = buildGiveawayEmbed(giveaway);
    await msg.edit({ embeds: [embed] });
    return;
  }

  if (customId === "giveaway_leave") {
    const msg = interaction.message;
    const giveaway = giveaways.get(msg.id);
    if (!giveaway || giveaway.ended) return;
    const idx = giveaway.entries.indexOf(user.id);
    if (idx === -1) {
      await interaction.reply({ embeds: [errorEmbed("Not Entered", "You are not in this giveaway.")], ephemeral: true });
      return;
    }
    giveaway.entries.splice(idx, 1);
    await interaction.reply({ embeds: [successEmbed("Left", "You have left the giveaway.")], ephemeral: true });
    const embed = buildGiveawayEmbed(giveaway);
    await msg.edit({ embeds: [embed] });
    return;
  }
}

export default event;
