import { Events, type Message, PermissionFlagsBits, EmbedBuilder, type ColorResolvable } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { handlePrefixCommand } from "../handlers/commandHandler.js";
import { autoModerate } from "../systems/antiSpam.js";
import { handleXP } from "../systems/leveling.js";
import { tickets } from "../systems/database.js";
import { Colors } from "../utils/colors.js";

const event: BotEvent = {
  name: Events.MessageCreate,
  async execute(message: Message) {
    if (message.author.bot || !message.guild) return;

    // Auto moderation
    const violation = await autoModerate(message);
    if (violation) {
      await message.delete().catch(() => null);

      const reasons: Record<string, string> = {
        spam: "⚡ **Auto-Mod:** Slow down! You're sending messages too fast.",
        scam: "🚫 **Auto-Mod:** Potential scam/phishing link detected.",
        mass_mention: "🚫 **Auto-Mod:** Too many mentions in one message.",
        invite_link: "🚫 **Auto-Mod:** Discord invite links are not allowed.",
        link: "🚫 **Auto-Mod:** External links are not allowed in this channel.",
      };

      const warn = await message.channel.send({
        content: `${message.author}`,
        embeds: [
          new EmbedBuilder()
            .setColor(Colors.error as ColorResolvable)
            .setDescription(reasons[violation] ?? "Message removed by auto-mod.")
            .setFooter({ text: "ShadowForge Security System" }),
        ],
      });
      setTimeout(() => warn.delete().catch(() => null), 5000);

      // Auto timeout on spam
      if (violation === "spam" && message.member) {
        await message.member.timeout(60 * 1000, "Auto-mod: Spam").catch(() => null);
      }
      return;
    }

    // Log ticket messages
    const ticket = tickets.get(message.channelId);
    if (ticket) {
      ticket.transcript.push(`[${new Date().toISOString()}] ${message.author.tag}: ${message.content}`);
    }

    // Handle XP
    await handleXP(message);

    // Handle prefix commands
    await handlePrefixCommand(message, message.client);
  },
};

export default event;
