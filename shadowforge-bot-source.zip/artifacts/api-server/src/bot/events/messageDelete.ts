import { Events, type Message, EmbedBuilder, type ColorResolvable, type TextChannel } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { getGuildConfig } from "../systems/database.js";
import { Colors } from "../utils/colors.js";

const event: BotEvent = {
  name: Events.MessageDelete,
  async execute(message: Message) {
    if (!message.guild || message.author?.bot) return;
    const config = getGuildConfig(message.guild.id);
    if (!config.logChannel) return;

    const logCh = message.guild.channels.cache.get(config.logChannel) as TextChannel | undefined;
    if (!logCh) return;

    const embed = new EmbedBuilder()
      .setColor(Colors.error as ColorResolvable)
      .setTitle("🗑️ Message Deleted")
      .addFields(
        { name: "Author", value: message.author ? `${message.author.tag} (${message.author.id})` : "Unknown", inline: true },
        { name: "Channel", value: `${message.channel}`, inline: true },
        { name: "Content", value: message.content?.slice(0, 1024) || "*No text content*" },
      )
      .setTimestamp();

    await logCh.send({ embeds: [embed] }).catch(() => null);
  },
};

export default event;
