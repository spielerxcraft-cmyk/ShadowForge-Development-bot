import { Events, type Message, EmbedBuilder, type ColorResolvable, type TextChannel } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { getGuildConfig } from "../systems/database.js";
import { Colors } from "../utils/colors.js";

const event: BotEvent = {
  name: Events.MessageUpdate,
  async execute(oldMessage: Message, newMessage: Message) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    const config = getGuildConfig(newMessage.guild.id);
    if (!config.logChannel) return;

    const logCh = newMessage.guild.channels.cache.get(config.logChannel) as TextChannel | undefined;
    if (!logCh) return;

    const embed = new EmbedBuilder()
      .setColor(Colors.warning as ColorResolvable)
      .setTitle("✏️ Message Edited")
      .setURL(newMessage.url)
      .addFields(
        { name: "Author", value: `${newMessage.author?.tag} (${newMessage.author?.id})`, inline: true },
        { name: "Channel", value: `${newMessage.channel}`, inline: true },
        { name: "Before", value: oldMessage.content?.slice(0, 512) || "*empty*" },
        { name: "After", value: newMessage.content?.slice(0, 512) || "*empty*" },
      )
      .setTimestamp();

    await logCh.send({ embeds: [embed] }).catch(() => null);
  },
};

export default event;
