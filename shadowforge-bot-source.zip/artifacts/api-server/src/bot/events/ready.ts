import { Events, ActivityType } from "discord.js";
import type { BotEvent } from "../handlers/eventHandler.js";
import { botLogger } from "../utils/logger.js";

const event: BotEvent = {
  name: Events.ClientReady,
  once: true,
  async execute(client: import("discord.js").Client) {
    botLogger.info(`✅ ShadowForge Bot is online as ${client.user?.tag}`);

    const activities = [
      { name: "ShadowForge Development", type: ActivityType.Watching },
      { name: ".help | ShadowForge", type: ActivityType.Playing },
      { name: "over the server", type: ActivityType.Watching },
      { name: "ShadowForge Support", type: ActivityType.Streaming, url: "https://twitch.tv/discord" },
    ];

    let i = 0;
    const setActivity = () => {
      const act = activities[i % activities.length]!;
      client.user?.setPresence({
        status: "online",
        activities: [act],
      });
      i++;
    };

    setActivity();
    setInterval(setActivity, 30000);

    botLogger.info(`📡 Serving ${client.guilds.cache.size} guild(s)`);
  },
};

export default event;
