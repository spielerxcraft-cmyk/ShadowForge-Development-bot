import { Collection, type Client, type ChatInputCommandInteraction, type Message } from "discord.js";
import { errorEmbed } from "../utils/embeds.js";
import { botLogger } from "../utils/logger.js";

export interface SlashCommand {
  data: { name: string; toJSON(): unknown };
  execute(interaction: ChatInputCommandInteraction): Promise<void>;
}

export interface PrefixCommand {
  name: string;
  aliases?: string[];
  description: string;
  usage?: string;
  execute(message: Message, args: string[], client: Client): Promise<void>;
}

export const slashCommands = new Collection<string, SlashCommand>();
export const prefixCommands = new Collection<string, PrefixCommand>();

export const PREFIX = ".";

export async function handleSlashCommand(interaction: ChatInputCommandInteraction) {
  const command = slashCommands.get(interaction.commandName);
  if (!command) return;
  try {
    await command.execute(interaction);
  } catch (err) {
    botLogger.error(err, `Error in slash command: ${interaction.commandName}`);
    const embed = errorEmbed("Command Error", "An error occurred while running this command.");
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ embeds: [embed], ephemeral: true });
    } else {
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
}

export async function handlePrefixCommand(message: Message, client: Client) {
  if (!message.content.startsWith(PREFIX) || message.author.bot) return;
  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const commandName = args.shift()?.toLowerCase();
  if (!commandName) return;

  let command = prefixCommands.get(commandName);
  if (!command) {
    for (const [, cmd] of prefixCommands) {
      if (cmd.aliases?.includes(commandName)) {
        command = cmd;
        break;
      }
    }
  }
  if (!command) return;

  try {
    await command.execute(message, args, client);
  } catch (err) {
    botLogger.error(err, `Error in prefix command: ${commandName}`);
    await message.reply({ embeds: [errorEmbed("Error", "Something went wrong running that command.")] });
  }
}
