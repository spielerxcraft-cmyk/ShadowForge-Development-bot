import type { Client } from "discord.js";
import { botLogger } from "../utils/logger.js";

export interface BotEvent {
  name: string;
  once?: boolean;
  execute(...args: unknown[]): Promise<void>;
}

export function registerEvent(client: Client, event: BotEvent) {
  if (event.once) {
    client.once(event.name, async (...args) => {
      try {
        await event.execute(...args);
      } catch (err) {
        botLogger.error(err, `Error in event: ${event.name}`);
      }
    });
  } else {
    client.on(event.name, async (...args) => {
      try {
        await event.execute(...args);
      } catch (err) {
        botLogger.error(err, `Error in event: ${event.name}`);
      }
    });
  }
}
