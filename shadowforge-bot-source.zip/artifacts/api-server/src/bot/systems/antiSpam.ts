import { Collection, type Message, type GuildMember } from "discord.js";
import { getGuildConfig, spamTracker } from "./database.js";

const messageTimestamps = new Collection<string, number[]>();
const scamKeywords = [
  "free nitro", "discord nitro", "steam gift", "free gift",
  "click here to claim", "limited time offer", "bit.ly", "tinyurl",
  "you have been selected", "claim your prize",
];

export function checkSpam(message: Message): boolean {
  if (!message.guild) return false;
  const config = getGuildConfig(message.guild.id);
  if (!config.antiSpam) return false;

  const key = `${message.guild.id}-${message.author.id}`;
  const now = Date.now();
  const timestamps = messageTimestamps.get(key) ?? [];
  const recent = timestamps.filter((t) => now - t < 5000);
  recent.push(now);
  messageTimestamps.set(key, recent);
  return recent.length >= config.spamThreshold;
}

export function checkScam(message: Message): boolean {
  if (!message.guild) return false;
  const config = getGuildConfig(message.guild.id);
  if (!config.antiScam) return false;
  const lower = message.content.toLowerCase();
  return scamKeywords.some((kw) => lower.includes(kw));
}

export function checkMassMention(message: Message): boolean {
  if (!message.guild) return false;
  const config = getGuildConfig(message.guild.id);
  if (!config.antiMassMention) return false;
  return message.mentions.users.size + message.mentions.roles.size >= config.maxMentions;
}

export function checkInviteLink(message: Message): boolean {
  if (!message.guild) return false;
  const config = getGuildConfig(message.guild.id);
  if (!config.antiInvite) return false;
  return /discord\.gg\/|discord\.com\/invite\//i.test(message.content);
}

export function checkLink(message: Message): boolean {
  if (!message.guild) return false;
  const config = getGuildConfig(message.guild.id);
  if (!config.antiLink) return false;
  return /https?:\/\//i.test(message.content);
}

export async function autoModerate(message: Message): Promise<string | null> {
  if (!message.guild || !message.member) return null;
  const member = message.member as GuildMember;
  if (member.permissions.has(8n)) return null; // Admin bypass

  if (checkSpam(message)) return "spam";
  if (checkScam(message)) return "scam";
  if (checkMassMention(message)) return "mass_mention";
  if (checkInviteLink(message)) return "invite_link";
  if (checkLink(message)) return "link";
  return null;
}
