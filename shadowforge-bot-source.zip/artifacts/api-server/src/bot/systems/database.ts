import { Collection } from "discord.js";

// In-memory storage (can be swapped for a real DB later)
// Warnings
export const warnings = new Collection<string, { userId: string; guildId: string; reason: string; moderator: string; timestamp: number }[]>();

// Levels/XP
export const levels = new Collection<string, { xp: number; level: number; messages: number }>();

// Invites
export const inviteTracker = new Collection<string, { inviterId: string; uses: number; fake: number; left: number }>();

// Tickets
export const tickets = new Collection<string, { userId: string; type: string; channelId: string; claimed: boolean; claimedBy?: string; transcript: string[] }>();

// Giveaways
export const giveaways = new Collection<string, {
  messageId: string;
  channelId: string;
  guildId: string;
  prize: string;
  winners: number;
  endsAt: number;
  hostId: string;
  entries: string[];
  ended: boolean;
  requirements?: string;
}>();

// Economy
export const economy = new Collection<string, { balance: number; daily: number; reputation: number; badges: string[] }>();

// Mutes (timeout tracking)
export const mutedUsers = new Collection<string, { userId: string; guildId: string; endsAt: number; reason: string }>();

// Config per guild
export const guildConfig = new Collection<string, {
  welcomeChannel?: string;
  welcomeMessage?: string;
  goodbyeChannel?: string;
  logChannel?: string;
  modLogChannel?: string;
  ticketCategory?: string;
  staffRole?: string;
  autoRole?: string;
  verifyRole?: string;
  antiRaid: boolean;
  antiSpam: boolean;
  antiLink: boolean;
  antiScam: boolean;
  antiMassMention: boolean;
  antiInvite: boolean;
  maxMentions: number;
  spamThreshold: number;
  levelRoles: Record<number, string>;
  modules: Record<string, boolean>;
}>();

export function getGuildConfig(guildId: string) {
  if (!guildConfig.has(guildId)) {
    guildConfig.set(guildId, {
      antiRaid: true,
      antiSpam: true,
      antiLink: false,
      antiScam: true,
      antiMassMention: true,
      antiInvite: false,
      maxMentions: 5,
      spamThreshold: 5,
      levelRoles: {},
      modules: {
        security: true,
        welcome: true,
        tickets: true,
        moderation: true,
        logging: true,
        giveaway: true,
        rewards: true,
        invites: true,
        economy: true,
        ai: true,
      },
    });
  }
  return guildConfig.get(guildId)!;
}

export function getUserEconomy(userId: string) {
  if (!economy.has(userId)) {
    economy.set(userId, { balance: 0, daily: 0, reputation: 0, badges: [] });
  }
  return economy.get(userId)!;
}

export function getUserLevel(key: string) {
  if (!levels.has(key)) {
    levels.set(key, { xp: 0, level: 0, messages: 0 });
  }
  return levels.get(key)!;
}

export function getXpForLevel(level: number): number {
  return 100 * Math.pow(level, 2) + 100;
}

export function getUserWarnings(guildId: string, userId: string) {
  const key = `${guildId}-${userId}`;
  return warnings.get(key) ?? [];
}

export function addWarning(guildId: string, userId: string, reason: string, moderator: string) {
  const key = `${guildId}-${userId}`;
  const existing = getUserWarnings(guildId, userId);
  existing.push({ userId, guildId, reason, moderator, timestamp: Date.now() });
  warnings.set(key, existing);
  return existing.length;
}

// Spam tracking
export const spamTracker = new Collection<string, { count: number; lastMessage: number }>();
