import {
  type Client, type TextChannel, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  type ColorResolvable,
} from "discord.js";
import { giveaways } from "./database.js";
import { Colors } from "../utils/colors.js";

export function buildGiveawayEmbed(data: {
  prize: string; winners: number; endsAt: number; hostId: string; entries: string[]; requirements?: string;
}): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(Colors.gold as ColorResolvable)
    .setTitle(`🎉 GIVEAWAY: ${data.prize}`)
    .setDescription(
      `React with 🎉 or click the button below to enter!\n\n` +
      `**Winners:** ${data.winners}\n` +
      `**Ends:** <t:${Math.floor(data.endsAt / 1000)}:R>\n` +
      `**Hosted by:** <@${data.hostId}>\n` +
      `**Entries:** ${data.entries.length}` +
      (data.requirements ? `\n\n**Requirements:** ${data.requirements}` : ""),
    )
    .setFooter({ text: "ShadowForge Giveaway System" })
    .setTimestamp(data.endsAt);
  return embed;
}

export function buildGiveawayRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("giveaway_enter").setLabel("Enter").setStyle(ButtonStyle.Success).setEmoji("🎉"),
    new ButtonBuilder().setCustomId("giveaway_leave").setLabel("Leave").setStyle(ButtonStyle.Danger).setEmoji("🚪"),
  );
}

export async function endGiveaway(client: Client, giveawayId: string): Promise<void> {
  const giveaway = giveaways.get(giveawayId);
  if (!giveaway || giveaway.ended) return;

  giveaway.ended = true;
  const channel = client.channels.cache.get(giveaway.channelId) as TextChannel | null;
  if (!channel) return;

  const msg = await channel.messages.fetch(giveaway.messageId).catch(() => null);
  if (!msg) return;

  const { entries, winners: winnerCount, prize } = giveaway;
  if (entries.length === 0) {
    const embed = new EmbedBuilder()
      .setColor(Colors.error as ColorResolvable)
      .setTitle(`🎉 GIVEAWAY ENDED: ${prize}`)
      .setDescription("No valid entries. No winners could be selected.")
      .setTimestamp();
    await msg.edit({ embeds: [embed], components: [] });
    return;
  }

  const shuffled = [...entries].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, Math.min(winnerCount, entries.length));

  const embed = new EmbedBuilder()
    .setColor(Colors.success as ColorResolvable)
    .setTitle(`🎉 GIVEAWAY ENDED: ${prize}`)
    .setDescription(
      `**Winners:** ${selected.map((id) => `<@${id}>`).join(", ")}\n` +
      `**Prize:** ${prize}\n` +
      `**Hosted by:** <@${giveaway.hostId}>`,
    )
    .setFooter({ text: "ShadowForge Giveaway System" })
    .setTimestamp();

  await msg.edit({ embeds: [embed], components: [] });
  await channel.send({
    content: `🎊 Congratulations ${selected.map((id) => `<@${id}>`).join(", ")}! You won **${prize}**!`,
    embeds: [
      new EmbedBuilder()
        .setColor(Colors.success as ColorResolvable)
        .setDescription(`Winners have been selected. DM <@${giveaway.hostId}> to claim your prize!`),
    ],
  });
}

export function scheduleGiveaway(client: Client, giveawayId: string, delay: number): void {
  setTimeout(() => endGiveaway(client, giveawayId), delay);
}
