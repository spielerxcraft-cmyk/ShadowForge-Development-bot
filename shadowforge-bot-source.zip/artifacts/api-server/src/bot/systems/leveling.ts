import { type Message, EmbedBuilder, type ColorResolvable } from "discord.js";
import { getUserLevel, getXpForLevel, getGuildConfig } from "./database.js";
import { Colors } from "../utils/colors.js";

export async function handleXP(message: Message): Promise<void> {
  if (!message.guild || message.author.bot) return;

  const key = `${message.guild.id}-${message.author.id}`;
  const data = getUserLevel(key);

  const xpGain = Math.floor(Math.random() * 15) + 10;
  data.xp += xpGain;
  data.messages += 1;

  const xpNeeded = getXpForLevel(data.level + 1);

  if (data.xp >= xpNeeded) {
    data.xp -= xpNeeded;
    data.level += 1;

    const embed = new EmbedBuilder()
      .setColor(Colors.gold as ColorResolvable)
      .setTitle("🎉 Level Up!")
      .setDescription(`Congratulations ${message.author}! You've reached **Level ${data.level}**!`)
      .addFields({ name: "Next Level", value: `${getXpForLevel(data.level + 1)} XP needed`, inline: true })
      .setThumbnail(message.author.displayAvatarURL())
      .setTimestamp();

    await message.channel.send({ embeds: [embed] });

    // Apply level roles
    const config = getGuildConfig(message.guild.id);
    const roleId = config.levelRoles[data.level];
    if (roleId && message.member) {
      const role = message.guild.roles.cache.get(roleId);
      if (role) {
        await message.member.roles.add(role).catch(() => null);
      }
    }
  }
}
