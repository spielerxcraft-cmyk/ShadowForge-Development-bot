import {
  type Guild, type User, type TextChannel,
  ChannelType, PermissionFlagsBits, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  type ColorResolvable,
} from "discord.js";
import { tickets, getGuildConfig } from "./database.js";
import { Colors } from "../utils/colors.js";

export type TicketType = "support" | "purchase" | "partnership" | "report" | "application";

const ticketEmojis: Record<TicketType, string> = {
  support: "🛠️",
  purchase: "💰",
  partnership: "🤝",
  report: "🚨",
  application: "📋",
};

export async function createTicket(
  guild: Guild,
  user: User,
  type: TicketType,
): Promise<TextChannel | null> {
  const config = getGuildConfig(guild.id);

  const existing = [...tickets.values()].find(
    (t) => t.userId === user.id && !t.transcript.includes("closed"),
  );
  if (existing) return null;

  const channel = await guild.channels.create({
    name: `${ticketEmojis[type]}-${type}-${user.username}`,
    type: ChannelType.GuildText,
    parent: config.ticketCategory ?? undefined,
    permissionOverwrites: [
      { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
      ...(config.staffRole ? [{ id: config.staffRole, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }] : []),
    ],
  }) as TextChannel;

  tickets.set(channel.id, {
    userId: user.id,
    type,
    channelId: channel.id,
    claimed: false,
    transcript: [],
  });

  const embed = new EmbedBuilder()
    .setColor(Colors.shadowforge as ColorResolvable)
    .setTitle(`${ticketEmojis[type]} ${type.charAt(0).toUpperCase() + type.slice(1)} Ticket`)
    .setDescription(
      `Hello ${user}, thank you for contacting **ShadowForge Development** support!\n\nA member of our team will assist you shortly. Please describe your issue in detail.\n\n**Ticket Type:** ${type.toUpperCase()}`,
    )
    .addFields(
      { name: "📌 Instructions", value: "• Be patient and respectful\n• Provide all relevant information\n• Do not ping staff unnecessarily" },
    )
    .setFooter({ text: "ShadowForge Development • Support System" })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ticket_claim").setLabel("Claim").setStyle(ButtonStyle.Primary).setEmoji("🎫"),
    new ButtonBuilder().setCustomId("ticket_close").setLabel("Close").setStyle(ButtonStyle.Danger).setEmoji("🔒"),
    new ButtonBuilder().setCustomId("ticket_transcript").setLabel("Transcript").setStyle(ButtonStyle.Secondary).setEmoji("📄"),
  );

  await channel.send({ content: `${user}`, embeds: [embed], components: [row] });
  return channel;
}

export async function closeTicket(channel: TextChannel): Promise<void> {
  const ticket = tickets.get(channel.id);
  if (!ticket) return;

  const embed = new EmbedBuilder()
    .setColor(Colors.error as ColorResolvable)
    .setTitle("🔒 Ticket Closing")
    .setDescription("This ticket will be closed in 5 seconds. Thank you for contacting ShadowForge Development!")
    .setTimestamp();

  await channel.send({ embeds: [embed] });
  setTimeout(() => channel.delete().catch(() => null), 5000);
  tickets.delete(channel.id);
}

export function getTicketPanelEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.shadowforge as ColorResolvable)
    .setTitle("🎫 ShadowForge Development Support")
    .setDescription("Select the type of ticket you need help with below.\n\nOur team is here to help you!")
    .addFields(
      { name: "🛠️ Support", value: "General support & questions", inline: true },
      { name: "💰 Purchase", value: "Purchases & billing", inline: true },
      { name: "🤝 Partnership", value: "Partnership requests", inline: true },
      { name: "🚨 Report", value: "Report a user/issue", inline: true },
      { name: "📋 Application", value: "Staff applications", inline: true },
    )
    .setFooter({ text: "ShadowForge Development • Ticket System" })
    .setTimestamp();
}
