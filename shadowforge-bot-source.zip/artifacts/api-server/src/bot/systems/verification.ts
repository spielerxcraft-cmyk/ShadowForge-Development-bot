import {
  type Guild, type User, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  type ColorResolvable,
} from "discord.js";
import { getGuildConfig } from "./database.js";
import { Colors } from "../utils/colors.js";

const pendingVerification = new Set<string>();

export function getVerificationEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(Colors.shadowforge as ColorResolvable)
    .setTitle("🛡️ Server Verification")
    .setDescription(
      "Welcome to **ShadowForge Development**!\n\nTo gain access to the server, please complete our verification process by clicking the button below.\n\n" +
      "✅ Click **Verify** to get access\n" +
      "🤖 This helps us keep the server safe from bots and raiders",
    )
    .setFooter({ text: "ShadowForge Development • Security System" })
    .setTimestamp();
}

export function getVerificationRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("verify_button")
      .setLabel("✅ Verify")
      .setStyle(ButtonStyle.Success),
  );
}

export async function verifyUser(guild: Guild, user: User): Promise<boolean> {
  const config = getGuildConfig(guild.id);
  if (!config.verifyRole) return false;

  const member = await guild.members.fetch(user.id).catch(() => null);
  if (!member) return false;

  const role = guild.roles.cache.get(config.verifyRole);
  if (!role) return false;

  await member.roles.add(role);
  return true;
}

export function isSuspiciousAccount(userId: string, createdAt: Date): boolean {
  const ageMs = Date.now() - createdAt.getTime();
  const ageDays = ageMs / (1000 * 60 * 60 * 24);
  return ageDays < 7; // Accounts less than 7 days old
}
