export const Colors = {
  primary: 0x5865f2,
  success: 0x57f287,
  warning: 0xfee75c,
  error: 0xed4245,
  info: 0x5865f2,
  purple: 0x9b59b6,
  gold: 0xf1c40f,
  dark: 0x2c2f33,
  shadowforge: 0x7289da,
} as const;
