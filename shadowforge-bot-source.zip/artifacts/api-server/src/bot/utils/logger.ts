import { logger as pinoLogger } from "../../lib/logger.js";

export const botLogger = pinoLogger.child({ module: "discord-bot" });
