import { type GuildMember, PermissionFlagsBits } from "discord.js";

export function isAdmin(member: GuildMember): boolean {
  return member.permissions.has(PermissionFlagsBits.Administrator);
}

export function isModerator(member: GuildMember): boolean {
  return (
    member.permissions.has(PermissionFlagsBits.ManageMessages) ||
    member.permissions.has(PermissionFlagsBits.BanMembers) ||
    member.permissions.has(PermissionFlagsBits.KickMembers)
  );
}

export function isOwner(member: GuildMember): boolean {
  return member.guild.ownerId === member.id;
}
